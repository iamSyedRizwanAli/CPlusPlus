#include "LinkedList.h"
#include <iostream>

LinkedList :: LinkedList()
{
	head = 0;
}

LinkedList :: LinkedList(const LinkedList & orig)
{
	if(orig.head == NULL)
	{
		head = 0;
	}	
	else
	{
		head = new Node;

		head -> data = orig.head ->data;
		Node * O = orig.head -> next;
		Node * temp = head;

		while(O != NULL)
		{
			temp -> next = new Node;
			temp = temp -> next;
			temp ->data = O -> data;
			O = O -> next;
		}
		temp -> next = 0;
	}
}

bool LinkedList :: search(int val)
{
	if(head != 0)
	{
		Node * temp = head;
		while(temp != 0)
		{
			if(temp -> data == val)
				return true;
			else
				temp = temp -> next;
		}
		return false;
	}
	else
		return false;
}

void LinkedList :: insert(int val)
{
	insertAtStart(val);
}

void LinkedList :: insertAtEnd(int val)
{
	Node * temp = new Node, *tempB;

	temp -> data = val;
	temp -> next = 0;

	tempB = head;

	if(tempB != 0)
	{
		while(tempB -> next != 0)
		{
			tempB = tempB -> next;	
		}
		tempB -> next = temp;

		temp = 0;
	}
	else
	{
		head = temp;
		temp = 0;
	}
}

void LinkedList :: insertAtStart(int val)
{
	Node * temp = new Node;
	temp -> data = val;
	temp -> next = head;
	head = temp;
}

void LinkedList :: insertSorted(int val)
{
	Node * temp = new Node;
	temp -> data = val;

	Node * curr = head, *prev = 0;

	while(curr != 0 && curr -> data < val)
	{
		prev = curr;
		curr = curr -> next;
	}
	if(curr == head)
	{
		temp -> next = head;
		head = temp;
	}
	else
	{
		prev-> next = temp;
		temp ->next = curr;
	}
}

void LinkedList :: display()
{
	if(head)
	{
		Node * temp= head;

		while(temp != 0)
		{
			std :: cout << temp -> data << " ";
			temp = temp->next;
		}
	}
}

bool LinkedList :: remove(int val)
{
	if(head)
	{
		Node * temp  = head, *prev = 0;
		
		while(temp != 0)
		{
			if(temp -> data == val)
			{
				if(head == temp)
					head = temp -> next;
				else
					prev -> next = temp -> next;
				
				delete temp;
				return true;
			}
			else
			{
				prev = temp;
				temp = temp -> next;
			}
		}
		return false;
	}
	return false;
}

bool LinkedList :: removeSorted(int val)
{
	if(head)
	{
		Node * temp  = head, *prev = 0;
		
		while(temp != 0 && temp -> data <= val)
		{
			if(temp -> data == val)
			{
				if(head == temp)
					head = temp -> next;
				else
					prev -> next = temp -> next;
				
				delete temp;
				return true;
			}
			else
			{
				prev = temp;
				temp = temp -> next;
			}
		}
		return false;
	}
	return false;
}

bool LinkedList :: removeAll(int val)
{
	if(head)
	{
		Node * temp  = head, *prev = 0, *tempB = 0;
		bool flag = 0;

		while(temp != 0)
		{
			if(temp -> data == val)
			{
				if(head == temp)
				{
					head = temp -> next;
					tempB = temp;
					temp = temp -> next;
				}
				else
				{
					prev -> next = temp -> next;
					tempB = temp;
					temp = temp -> next;
				}
				delete tempB;
				flag = 1;
			}
			else
			{
				prev = temp;
				temp = temp -> next;
			}
		}
		return flag;
	}
	return false;
}

bool LinkedList :: removeAllSorted(int val)
{
	return removeAll(val);
}

bool LinkedList :: removeLastNodes(int & val)
{
	if(head)
	{
		Node * temp = head, * prev = 0;

		while(temp -> next != 0)
		{
			prev = temp;
			temp = temp -> next;
		}
		
		if(head == temp)
		{
			head = 0;
			val = temp -> data;
			delete temp;
		}
		else
		{
			prev -> next = 0;
			val = temp -> data;
			delete temp;
		}
		return true;
	}
	return false;
}

bool LinkedList :: removeSecondLastNode(int & val)
{
	if(head)
	{
		Node * temp = head, * prev = 0, *prev2 = 0;

		while(temp -> next != 0)
		{
			prev2 = prev;
			prev = temp;
			temp = temp -> next;
		}
		
		if(head == temp)
		{
			return false;
		}
		else
		{
			if(prev2 == 0)
			{
				val = head->data;
				head = temp;
			}
			else
			{
				prev2 -> next = temp;
				val =  prev -> data;
			}
			delete prev;
		}
		return true;
	}
	return false;
}

bool LinkedList :: removeKthElement(int k, int & val)
{
	if(head)
	{
		Node * temp = head, * prev = 0, * prev2 = 0;
		int count = 1;

		while(count < k && temp != 0)
		{
			prev2 = prev;
			prev = temp;
			temp = temp -> next;
			count++;
		}

		if(temp == 0 && count == k || count > k)
			return false;

		if(head == temp)
		{
			head = head -> next;
			val = temp -> data;
			delete temp;
			return true;
		}
		if(prev2 == 0)
		{
			if(temp)
			{
				prev -> next = temp -> next;
				val = temp -> data;
				delete temp;
			}
			else
			{
				prev-> next = 0;
				val = prev -> data;
			}
			
			return true;
		}
		else
		{
			val = temp -> data;
			prev -> next = temp -> next;
			delete temp;
			return true;
		}
	}
	return false;
}

void LinkedList :: combine(LinkedList & list1, LinkedList & list2)
{
	if(head)
	{
		this -> ~LinkedList();
	}
	
	head = list1.head;
	list1.head = 0;
	
	Node * temp = head;

	while(temp != 0 && temp -> next != 0)
		temp = temp -> next;

	if(temp)
		temp -> next = list2.head;
	else
		temp = list2.head;

	list2.head = 0;
}

void LinkedList :: shuffleMerge(LinkedList & list1, LinkedList & list2)
{
	if(head)
	{
		this -> ~LinkedList();
	}

	if(list1.head)
	{
		head = list1.head;
		list1.head = list1.head -> next;
	}

	Node * temp = head;
	
	while(list1.head && list2.head)
	{
		temp -> next = list2.head;
		list2.head = list2.head -> next;
		temp = temp -> next;
		temp -> next = list1.head;
		list1.head = list1.head -> next;
		temp = temp -> next;
	}
	while(list2.head)
	{
		temp -> next = list2.head;
		list2.head = list2.head -> next;
		temp = temp -> next;
	}
	while(list1.head)
	{
		temp -> next = list1.head;
		list1.head = list1.head -> next;
		temp = temp -> next;
	}

	temp -> next = 0;
}

LinkedList :: ~LinkedList()
{
	if(head)
	{
		Node * tempA;

		while(head != 0)
		{
			tempA = head->next;
			delete head;
			head = tempA;
		}
	}
}

bool LinkedList :: isEmpty()
{
	return head == 0 ? true : false;
}

int LinkedList :: findLength()
{
	int count = 0;
	Node * temp = head;

	while(temp)
	{
		temp = temp -> next;
		count++;
	}

	return count;
}