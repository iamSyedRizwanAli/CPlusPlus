#ifndef GRAPHLINKED_H
#define GRAPHLINKED_H

#include"LinkedList.h"

class GraphLinked {
private:
	LinkedList * adjMatrix; 
	int maxVertices; // Max number of vertices which can be present in the graph
	int n; // Current number of vertices present in the graph
	bool* visited; // Array to keep track of visited/unvisited vertices

	bool isFull();
	void DFS(int v);
	void BFS(int v);
public:
	GraphLinked (int maxV, int currV);
	~GraphLinked (); 
	bool addVertex (int& v);
	bool addEdge (int u, int v); 
	bool removeEdge (int u, int v); 
	bool isEmpty();

	bool isComplete();
	void clear();
	void display();
	int inDegree(int v);
	int outDegree(int v);
	void findUniversalVertex();
	void findIsolatedVertex();
	void DFS();

	void BFS();
};

#endif