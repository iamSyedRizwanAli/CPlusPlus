#include"Graph.h"
#include <iostream>
using namespace std;

Graph :: Graph(int maxV, int currV)
{
	maxVertices = maxV;
	n = currV;

	adjacencyMatrix = new int * [maxV];
	for(int i = 0 ; i < maxV ; i++)
	{
		adjacencyMatrix[i] = new int [maxV];
		for(int j = 0 ; j < maxV ; j++)
			adjacencyMatrix[i][j] = 0;
	}

	visited = new bool [maxV];

	for(int i = 0 ; i < maxV ; i++)
		visited[i] = false;
}

Graph :: ~Graph()
{
	if(adjacencyMatrix)
	{
		for(int i = 0 ; i < maxVertices ;i++)
			delete [] adjacencyMatrix[i];
		delete [] adjacencyMatrix;
		adjacencyMatrix = 0;

		delete [] visited;
		visited = 0;
	}
}

bool Graph :: isEmpty()
{

	for(int i = 0 ; i < n ; i++)
		for(int j = 0 ; j < n ; j++)
			if(adjacencyMatrix[i][j] == 1)
				return false;

	return true;
}

bool Graph :: isFull()
{
	return n == maxVertices ? true : false;
}

bool Graph :: addVertex(int & v)
{
	if(isFull())
		return false;
	else
	{
		n++;
		v = n;
		return true;
	}
}

bool Graph :: addEdge(int u, int v)
{
	if(u == v)
		return false;
	else
	{
		adjacencyMatrix[u][v] = 1;
		return true;
	}
	return false;
}

bool Graph :: removeEdge(int u, int v)
{
	if(u == v)
		return false;
	else if(adjacencyMatrix[u][v] == 1)
	{
		adjacencyMatrix[u][v] = 0;
		return true;
	}
	else
		return false;
}

bool Graph :: isComplete()
{
	int e = 0;

	for(int i = 0 ; i < n ; i++)
	{
		for(int j = 0 ; j < n ; j++)
		{
			e += adjacencyMatrix[i][j];
		}
	}

	return e == (n * (n - 1)) ? true : false;
	
}

void Graph :: clear()
{
	for(int i = 0 ; i < n ; i++)
		for(int j = 0 ; j < n ; j++)
			adjacencyMatrix[i][j] = 0;
}

void Graph :: display()
{
	cout << "\n  ";
	for(int i = 0 ; i < n ; i++)
		cout << i << ' ';
	cout << '\n';

	for(int i = 0 ; i < n ; i++)
	{
		cout << i << ' ';
		for(int j = 0 ; j < n ; j++)
			cout << adjacencyMatrix[i][j] << ' ';
		cout << '\n';
	}
}

int Graph :: inDegree(int v)
{
	if(v < 0 || v > n)
		return -1;
	else
	{
		int count = 0;
		for(int i = 0 ; i < n ; i++)
			count += adjacencyMatrix[i][v];
		return count;
	}
}

int Graph :: outDegree(int v)
{
	if(v < 0 || v > n)
		return -1;
	else
	{
		int count = 0 ; 
		for(int i = 0 ; i < n ; i++)
			count += adjacencyMatrix[v][i];
		return count;
	}
}

void Graph :: findUniversalVertex()
{
	int numOfUniVertex = 0;

	for(int i = 0 ; i < n ; i ++)
	{
		if(outDegree(i) == n - 1)
				numOfUniVertex++;
	}

	if(numOfUniVertex != 0)
		cout << "\nThe total number of Universal Vertex(\ices) are " << numOfUniVertex << "\n";
	else
		cout << "\nThere are no universal vertices\n";
}

void Graph :: findIsolatedVertex()
{
	int numOfIsoVertex = 0;
	
	for(int i = 0 ; i < n ; i ++)
	{
		if(inDegree(i) == 0 && inDegree(i) == 0)
				numOfIsoVertex++;
	}

	if(numOfIsoVertex)
		cout << "\nThe total number of Isolated Vertex(\ices) are " << numOfIsoVertex << "\n";
	else
		cout << "\nThere are no isolated vertices\n";
}

void Graph :: DFS()
{
	int start = 0;
	cout << "\nEnter a starting vertex: ";
	cin >> start;

	if(start >= 0 && start < n)
	{
		DFS(start);
		
		for(int i = 0 ; i < n ; i++)
			if(visited[i] == false)
			{
				cout << '\n';
				DFS(i);
			}
		cout << '\n';
	}
	else
		cout << "\nWrong Vertex\n";
}

void Graph :: DFS(int v)
{
	if(v >= 0 && v < n && !visited[v])
	{
		visited[v] = 1;
		cout << v;
		for(int i = 0 ; i < n ; i++)
			if(adjacencyMatrix[v][i])
				DFS(i);
	}
}

Graph :: Graph(const Graph & g)
{
	maxVertices = g.maxVertices;
	n = g.n;

	adjacencyMatrix = new int * [g.maxVertices];
	for(int i = 0 ; i < maxVertices ; i++)
	{
		adjacencyMatrix[i] = new int [maxVertices];
		for(int j = 0 ; j < maxVertices ; j++)
			adjacencyMatrix[i][j] = g.adjacencyMatrix[i][j];
	}

	visited = new bool [maxVertices];

	for(int i = 0 ; i < maxVertices ; i++)
		visited[i] = false;
}

void Graph :: BFS()
{
	int start = 0;
	cout << "\nEnter a starting vertex: ";
	cin >> start;

	if(start >= 0 && start < n)
	{
		BFS(start);
		for(int i = 0 ; i < n ; i++)
			if(visited[i] == false)
			{
				cout << '\n';
				BFS(i);
			}
		cout << '\n';
	}
	else
		cout << "\nWrong Vertex\n";
}

void Graph :: BFS(int v)
{
	if(v >= 0 && v < n && !visited[v])
	{
		
		visited[v] = true;
		cout << v;

		for(int i = 0 ; i < n ; i++)
			if(adjacencyMatrix[v][i] && !visited[i])
			{
				cout << i;
				visited[i] = true;
			}
	}
}