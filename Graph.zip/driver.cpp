#include<iostream>
using namespace std;
#include "Graph.h"
#include "GraphLinked.h"
void main()
{
	Graph g(6, 6);
	g.addEdge(0,4);
	g.addEdge(0,5);
	g.addEdge(1,4);
	g.addEdge(1,5);
	g.addEdge(0,4);
	g.addEdge(1,2);
	g.addEdge(4,3);
	g.addEdge(5,0);
	g.addEdge(3,1);

	g.display();

	g.BFS();

	/*GraphLinked l(5,5);
	l.addEdge(0,4);
	l.addEdge(1,0);
	l.addEdge(3,1);
	l.addEdge(2,3);
	l.addEdge(0,2);
	l.addEdge(0,3);
	l.addEdge(0,1);
	l.addEdge(0,4);
	l.addEdge(0,0);

	l.display();

	l.findUniversalVertex();*/

	//l.BFS();
}