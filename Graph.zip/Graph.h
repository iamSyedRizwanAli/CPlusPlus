#ifndef GRAPH_H
#define GRAPH_H

#include"LinkedList.h"

class Graph
{
private:
	int ** adjacencyMatrix; 
	int maxVertices;
	int n;
	bool * visited;

	bool isFull();
	void DFS(int v);
	void BFS(int v);
public:
	Graph(int maxV, int currV);
	Graph(const Graph & g);
	~Graph();
	bool addVertex(int & v);
	bool addEdge(int u, int v);
	bool removeEdge(int u, int v);
	bool isComplete();
	bool isEmpty();
	void clear();
	void display();
	int inDegree(int v);
	int outDegree(int v);
	void findUniversalVertex();
	void findIsolatedVertex();
	void DFS();
	void BFS();
};

#endif