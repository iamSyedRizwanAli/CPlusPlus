#include"GraphLinked.h"
#include<iostream>
using namespace std;

GraphLinked :: GraphLinked(int maxV, int currV)
{
	if(maxV > 0 && currV > 0)
	{
		maxVertices = maxV;
		n = currV;

		adjMatrix = new LinkedList [maxV];

		visited = new bool [maxVertices];
		for(int i = 0 ; i < maxV ; i++)
			visited[i] = false;
	}
	else
	{
		maxVertices = n = 0;
		adjMatrix = 0;
		visited = 0;
	}
}

GraphLinked :: ~GraphLinked()
{
	if(adjMatrix)
	{
		for(int i = 0 ; i < n ; i++)
			adjMatrix[i].~LinkedList();
		delete [] adjMatrix;
		adjMatrix = 0;

		delete [] visited;
		visited = 0;
	}
}

bool GraphLinked :: isFull()
{
	return n == maxVertices ? true : false;
}

bool GraphLinked :: isEmpty()
{
	for(int i = 0 ; i < n ; i++)
	{
		if(!adjMatrix[i].isEmpty())
			return false;
	}
	return true;
}

bool GraphLinked :: addVertex(int & ind)
{
	if(!isFull())
	{
		n++;
		ind = n;
		return true;
	}
	return false;
}

bool GraphLinked :: addEdge(int u, int v)
{
	if(u == v || u < 0 || v < 0 || u > n || u > n || adjMatrix[u].search(v))
		return false;
	else
	{
		adjMatrix[u].insertSorted(v);
		return true;
	}
}

bool GraphLinked :: removeEdge(int u, int v)
{
	if(u == v || u > n || v > n || u < 0 || v < 0)
		return false;
	else
		return adjMatrix[u].remove(v);
}

bool GraphLinked :: isComplete()
{
	int e = 0;

	for(int i = 0 ; i < n ; i++)
		e += adjMatrix[i].findLength();

	return e == (n * (n - 1)) ? true : false;
}

void GraphLinked :: clear()
{
	for(int i = 0 ; i < n ; i++)
		adjMatrix[i].~LinkedList();
}

int GraphLinked :: inDegree(int v)
{
	int count = 0;

	if(v > 0 && v < n)
		for(int i = 0 ; i < n ; i ++)
			if(adjMatrix[i].search(v))
				count++;

	return count;
}

int GraphLinked :: outDegree(int v)
{
	if(v < 0 || v > n)
		return 0;
	else
		return adjMatrix[v].findLength();
}

void GraphLinked :: findUniversalVertex()
{
	int noOfUniVertices = 0;

	for(int i = 0 ; i < n ; i++)
		if(outDegree(i) == n - 1)
			noOfUniVertices++;

	if(noOfUniVertices)
		cout << "\nThe total number of Universal Vertex(\ices) are " << noOfUniVertices << "\n";
	else
		cout << "\nThere are no universal vertices\n";
}

void GraphLinked :: findIsolatedVertex()
{
	int noOfIsoVertices = 0;

	for(int i = 0 ; i < n ; i++)
		if(inDegree(i) == outDegree(i) == 0)
			noOfIsoVertices++;

	if(noOfIsoVertices)
		cout << "\nThe total number of Isolated Vertex(\ices) are " << noOfIsoVertices << "\n";
	else
		cout << "\nThere are no isolated vertices\n";
}

void GraphLinked :: display()
{
	for(int i = 0 ; i < n ; i++)
	{
		cout << i << " -> ";
		adjMatrix[i].display();
		cout << '\n';
	}
}

void GraphLinked :: DFS()
{
	int start = 0;
	cout << "\nEnter a starting vertex: ";
	cin >> start;

	if(start >= 0 && start < n)
	{
		DFS(start);
		
		for(int i = 0 ; i < n ; i++)
			if(visited[i] == false)
			{
				cout << '\n';
				DFS(i);
			}
		cout << '\n';
	}
	else
		cout << "\nWrong Vertex\n";
}

void GraphLinked :: DFS(int v)
{
	if(v >= 0 && v < n && !visited[v])
	{
		visited[v] = true;
		cout << v;

		for(int i = 0; i < n ; i++)
			if(adjMatrix[v].search(i))
				DFS(i);
	}
}

void GraphLinked :: BFS()
{
		int start = 0;
	cout << "\nEnter a starting vertex: ";
	cin >> start;

	if(start >= 0 && start < n)
	{
		BFS(start);
		for(int i = 0 ; i < n ; i++)
			if(visited[i] == false)
			{
				cout << '\n';
				BFS(i);
			}
		cout << '\n';
	}
	else
		cout << "\nWrong Vertex\n";
}

void GraphLinked :: BFS(int v)
{
	if(v >= 0 && v < n && !visited[v])
	{
		
		visited[v] = true;
		cout << v;

		for(int i = 0 ; i < n ; i++)
			if(adjMatrix[v].search(i) && !visited[i])
			{
				cout << i;
				visited[i] = true;
			}
	}
}