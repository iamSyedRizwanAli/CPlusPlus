#include <iostream>
#include <ctime>
using namespace std;

void displayMatrix (char ** matrix);
void displayInstructions();
bool gameplay(char ** matrix);
bool implementChoice(char ** matrix, char & choice, char sign);
bool foundWinner(char ** matrix, char sign);
bool systemThinking(char ** matrix, char userChoice);

void main()
{
	displayInstructions();
	char ** matrix = new char *[3];

	int vals = 49;

	for(int i = 0 ; i < 3 ; i ++)
	{
		matrix[i] = new char[3];
		for(int x = 0; x < 3; x++)
		{
			matrix[i][x] = vals;
			vals++;
		}
	}

	displayMatrix(matrix);
	gameplay(matrix);

	for(int i = 0 ; i < 3 ; i ++)
	{
		delete [] matrix[i];
	}
	delete [] matrix;

	cin.ignore();
	cout << "Hit enter to continue...";
	cin.get();

}

void displayInstructions()
{
	cout << "You have to choose a single coloumn out of these 9 coloumn\nonce a coloumn selected by computer or you will not be selected again\n";
}

void displayMatrix(char ** matrix)
{
	for(int i = 0 ; i < 3 ; i++)
	{
		for(int j = 0 ; j < 3; j++)
			cout << matrix[i][j] << ' ';
		cout << endl;
	}
}

bool implementChoice(char ** matrix, char & choice, char sign)
{
	int ourChoice = choice - 48;
	if(ourChoice < 1 || ourChoice > 9)
		return false;
	else
	{
		ourChoice --;
		int row = ourChoice / 3;
		int col = ourChoice % 3;

		if(matrix[row][col] == choice)
		{
			matrix[row][col] = sign;
			return true;
		}
		else
			return false;
	}
}

bool foundWinner(char ** matrix ,char sign)
{
	if(matrix[0][0] == matrix[0][1] && matrix[0][1] == matrix[0][2] && matrix[0][2] == sign)
		return true;
	else if(matrix[0][0] == matrix[1][1] && matrix[1][1] == matrix[2][2] && matrix[2][2] == sign)
		return true;
	else if(matrix[0][2] == matrix[1][1] && matrix[1][1] == matrix[2][0] && matrix[2][0] == sign)
		return true;
	else if(matrix[0][0] == matrix[1][0] && matrix[1][0] == matrix[2][0] && matrix[2][0] == sign)
		return true;
	else if(matrix[0][2] == matrix[1][2] && matrix[1][2] == matrix[2][2] && matrix[2][2] == sign)
		return true;
	else if(matrix[0][1] == matrix[1][1] && matrix[1][1] == matrix[2][1] && matrix[2][1] == sign)
		return true;
	else if(matrix[1][0] == matrix[1][1] && matrix[1][1] == matrix[1][2] && matrix[1][2] == sign)
		return true;
	else if(matrix[2][0] == matrix[2][1] && matrix[2][1] == matrix[2][2] && matrix[2][2] == sign)
		return true;

	return false;
}

bool gameplay(char ** matrix)
{
	char choice;
	srand(time(NULL));
	int count = 0;

	while(count < 10)
	{
		cout << "Select a coloumn: ";
		cin >> choice;

		if(implementChoice(matrix, choice, 'X'))
		{
			count++;

			if(count >= 5)
			{
				if(foundWinner(matrix, 'X'))
				{
					system("cls");
					cout << "You won\n";
					displayMatrix(matrix);
					return true;
				}
			}

			if(count < 9)
			{
				if(count < 2 || !systemThinking(matrix, choice))
				{					
					char systemChoice = (rand() % 9) + 1;
	
					systemChoice += 48;
					while(!implementChoice(matrix, systemChoice, 'O'))
					{
						systemChoice = (rand() % 9) + 1;
						systemChoice += 48;
					}
									
					system("cls");
					cout << "\nSystem Selected: " << systemChoice << '\n';

				}
				if(count > 5)
				{
					if(foundWinner(matrix, 'O'))
					{
						cout << "Computer won\n";
						displayMatrix(matrix);
						return true;
					}
				}
			}
			count++;
			displayMatrix(matrix);

		}
		else
		{
			system("cls");
			cout << "\nWrong Column!\n";
			displayMatrix(matrix);
		}
	}


	if(count == 10)
	{
		system("cls");
		cout << "Game Draw\n";
		displayMatrix(matrix);
	}

	return false;
}

bool systemThinking(char ** matrix, char userChoice)
{
	
	char systemChoice;
	int opponentChoice = userChoice - 48;

	bool flag = false;

	opponentChoice--;
	int row = opponentChoice / 3;
	int col = opponentChoice % 3;
	opponentChoice ++;

	if(opponentChoice == 5)
	{
		if(matrix[0][0] == matrix[1][1] && matrix[2][2] != 'O')
		{
			flag = 1;
			systemChoice = matrix[2][2];
			matrix[2][2] = 'O';
		}
		else if(matrix[0][1] == matrix[1][1] && matrix[2][1] != 'O') // ELSE_IF2A
		{
			flag = 1;
			systemChoice = matrix[2][1];
			matrix[2][1] = 'O';
		}
		else if(matrix[0][2] == matrix[1][1] && matrix[2][0] != 'O') // ELSE_IF2B
		{
			flag = 1;
			systemChoice = matrix[2][0];
			matrix[2][0] = 'O';
		}
		else if(matrix[1][0] == matrix[1][1] && matrix[1][2] != 'O') // ELSE_IF2C
		{
			flag = 1;
			systemChoice = matrix[1][2];
			matrix[1][2] = 'O';
		}
		else if(matrix[1][2] == matrix[1][1] && matrix[1][0] != 'O') // ELSE_IF2D
		{
			flag = 1;
			systemChoice = matrix[1][0];
			matrix[1][0] = 'O';
		}
		else if(matrix[2][0] == matrix[1][1] && matrix[0][2] != 'O') // ELSE_IF2E
		{
			flag = 1;
			systemChoice = matrix[0][2];
			matrix[0][2] = 'O';
		}
		else if(matrix[2][1] == matrix[1][1] && matrix[0][1] != 'O') // ELSE_IF2F
		{
			flag = 1;
			systemChoice = matrix[0][1];
			matrix[0][1] = 'O';
		}
		else if(matrix[2][2] == matrix[1][1] && matrix[0][0] != 'O') // ELSE_IF2G
		{
			flag = 1;
			systemChoice = matrix[0][0];
			matrix[0][0] = 'O';
		}
	}
	else
	{
		if(row == 0)
		{
			if(col == 0)
			{
				if(matrix[0][0] ==	matrix[0][1] && matrix[0][2] != 'O') // ELSE_IF3A
				{
					flag = 1;
					systemChoice = matrix[0][2];
					matrix[0][2] = 'O';
				}
				else if(matrix[0][0] == matrix[1][0] && matrix[2][0] != 'O') // ELSE_IF3B
				{
					flag = 1;
					systemChoice = matrix[2][0];
					matrix[2][0] = 'O';
				}
				else if(matrix[0][0] == matrix[1][1] && matrix[2][2] != 'O') // ELSE_IF3C
				{
					flag = 1;
					systemChoice = matrix[2][2];
					matrix[2][2] = 'O';
				}
				else if(matrix[0][0] == matrix[2][2] && matrix[1][1] != 'O') // ELSE_IF3D
				{
					flag = 1;
					systemChoice = matrix[1][1];
					matrix[1][1] = 'O';
				}
				else if(matrix[0][0] == matrix[0][2] && matrix[0][1] != 'O') // ELSE_IF3E
				{
					flag = 1;
					systemChoice = matrix[0][1];
					matrix[0][1] = 'O';
				}
				else if(matrix[0][0] == matrix[2][0] && matrix[1][0] != 'O') // ELSE_IF3F
				{
					flag = 1;
					systemChoice = matrix[1][0];
					matrix[1][0] = 'O';
				}
			}
			else if(col == 1)
			{
				if(matrix[0][1] == matrix[0][0] && matrix[0][2] != 'O') // ELSE_IF4A
				{
					flag = 1;
					systemChoice = matrix[0][2];
					matrix[0][2] = 'O';
				}
				else if(matrix[0][1] == matrix[0][2] && matrix[0][0] != 'O') // ELSE_IF4B
				{
					flag = 1;
					systemChoice = matrix[0][0];
					matrix[0][0] = 'O';
				}
				else if(matrix[0][1] == matrix[1][1] && matrix[2][1] != 'O') // ELSE_IF4C
				{
					flag = 1;
					systemChoice = matrix[2][1];
					matrix[2][1] = 'O';
				}
				else if(matrix[0][1] == matrix[2][1] && matrix[1][1] != 'O') // ELSE_IF4D
				{
					flag = 1;
					systemChoice = matrix[1][1];
					matrix[1][1] = 'O';
				}
			}
			else 
			{
				if(matrix[0][2] == matrix[0][1] && matrix[0][0] != 'O') // ELSE_IF5A
				{
					flag = 1;
					systemChoice = matrix[0][0];
					matrix[0][0] = 'O';
				}
				else if(matrix[0][2] == matrix[1][2] && matrix[2][2] != 'O') // ELSE_1F5B
				{
					flag = 1;
					systemChoice = matrix[2][2];
					matrix[2][2] = 'O';
				}
				else if(matrix[0][2] == matrix[1][1] && matrix[2][0] != 'O') // ELSE_IF5C
				{
					flag = 1;
					systemChoice = matrix[2][0];
					matrix[2][0] = 'O';
				}
				else if(matrix[0][2] == matrix[0][0] && matrix[0][1] != 'O') // ELSE_IF5D
				{
					flag = 1;
					systemChoice = matrix[0][1];
					matrix[0][1] = 'O';
				}
				else if(matrix[0][2] == matrix[2][2] && matrix[1][2] != 'O') // ELSE_IF5E
				{
					flag = 1;
					systemChoice = matrix[1][2];
					matrix[1][2] = 'O';
				}
				else if(matrix[0][2] == matrix[2][0] && matrix[1][1] != 'O') // ELSE_IF5F
				{
					flag = 1;
					systemChoice = matrix[1][1];
					matrix[1][1] = 'O';
				}
			}
		}
		else if(row == 2)
		{
			if(col == 0)
			{
				if(matrix[2][0] ==	matrix[2][1] && matrix[2][2] != 'O') // ELSE_IF6A
				{
					flag = 1;
					systemChoice = matrix[2][2];
					matrix[2][2] = 'O';
				}
				else if(matrix[2][0] == matrix[1][0] && matrix[0][0] != 'O') // ELSE_IF6B
				{
					flag = 1;
					systemChoice = matrix[0][0];
					matrix[0][0] = 'O';
				}
				else if(matrix[2][0] == matrix[1][1] && matrix[0][2] != 'O') // ELSE_IF6C
				{
					flag = 1;
					systemChoice = matrix[0][2];
					matrix[0][2] = 'O';
				}
				else if(matrix[2][0] == matrix[0][0] && matrix[1][0] != 'O') // ELSE_IF6D
				{
					flag = 1;
					systemChoice = matrix[1][0];
					matrix[1][0] = 'O';
				}
				else if(matrix[2][0] == matrix[0][2] && matrix[1][1] != 'O') // ELSE_IF6E
				{
					flag = 1;
					systemChoice = matrix[1][1];
					matrix[1][1] = 'O';
				}
				else if(matrix[2][0] == matrix[2][2] && matrix[2][1] != 'O') // ELSE_IF6F
				{
					flag = 1;
					systemChoice = matrix[2][1];
					matrix[2][1] = 'O';
				}
			}
			else if(col == 1)
			{
				if(matrix[2][1] == matrix[2][0] && matrix[2][2] != 'O') // ELSE_IF7A
				{
					flag = 1;
					systemChoice = matrix[2][2];
					matrix[2][2] = 'O';
				}
				else if(matrix[2][1] == matrix[2][2] && matrix[2][0] != 'O') // ELSE_IF7B
				{
					flag = 1;
					systemChoice = matrix[2][0];
					matrix[2][0] = 'O';
				}
				else if(matrix[2][1] == matrix[1][1] && matrix[0][1] != 'O') // ELSE_IF7C
				{
					flag = 1;
					systemChoice = matrix[0][1];
					matrix[0][1] = 'O';
				}
				else if(matrix[0][1] == matrix[2][1] && matrix[1][1] != 'O') // ELSE_IF7D
				{
					flag = 1;
					systemChoice = matrix[1][1];
					matrix[1][1] = 'O';
				}
			}
			else 
			{
				if(matrix[2][2] == matrix[2][1] && matrix[2][0] != 'O') // ELSE_IF8A
				{
					flag = 1;
					systemChoice = matrix[2][0];
					matrix[2][0] = 'O';
				}
				else if(matrix[2][2] == matrix[1][2] && matrix[0][2] != 'O') // ELSE_IF8B
				{
					flag = 1;
					systemChoice = matrix[0][2];
					matrix[0][2] = 'O';
				}
				else if(matrix[2][2] == matrix[1][1] && matrix[0][0] != 'O') // ELSE_IF8C
				{
					flag = 1;
					systemChoice = matrix[0][0];
					matrix[0][0] = 'O';
				}
				else if(matrix[2][2] == matrix[2][0] && matrix[2][1] != 'O') // ELSE_IF8D
				{
					flag = 1;
					systemChoice = matrix[2][1];
					matrix[2][1] = 'O';
				}
				else if(matrix[0][2] == matrix[2][2] && matrix[1][2] != 'O') // ELSE_IF8E
				{
					flag = 1;
					systemChoice = matrix[1][2];
					matrix[1][2] = 'O';
				}
				else if(matrix[2][2] == matrix[0][0] && matrix[1][1] != 'O') // ELSE_IF8F
				{
					flag = 1;
					systemChoice = matrix[1][1];
					matrix[1][1] = 'O';
				}
			}
		}
		else
		{
			if(col == 0)
			{
				if(matrix[1][0] ==	matrix[1][1] && matrix[1][2] != 'O') // ELSE_IF9A
				{
					flag = 1;
					systemChoice = matrix[1][2];
					matrix[1][2] = 'O';
				}
				else if(matrix[1][0] == matrix[2][0] && matrix[0][0] != 'O') // ELSE_IF9B
				{
					flag = 1;
					systemChoice = matrix[0][0];
					matrix[0][0] = 'O';
				}
				else if(matrix[1][0] == matrix[0][0] && matrix[2][0] != 'O') // ELSE_IF9C
				{
					flag = 1;
					systemChoice = matrix[2][0];
					matrix[2][0] = 'O';
				}
				else if(matrix[1][0] == matrix[1][2] && matrix[1][1] != 'O') // ELSE_IF9D
				{
					flag = 1;
					systemChoice = matrix[1][1];
					matrix[1][1] = 'O';
				}
			}
			else if(col == 2)
			{
				if(matrix[1][2] ==	matrix[1][1] && matrix[1][0] != 'O') // ELSE_IF10A
				{
					flag = 1;
					systemChoice = matrix[1][0];
					matrix[1][0] = 'O';
				}
				else if(matrix[1][2] == matrix[0][2] && matrix[2][2] != 'O') // ELSE_IF10B
				{
					flag = 1;
					systemChoice = matrix[2][2];
					matrix[2][2] = 'O';
				}
				else if(matrix[1][2] == matrix[2][2] && matrix[0][2] != 'O') // ELSE_IF10C
				{
					flag = 1;
					systemChoice = matrix[0][2];
					matrix[0][2] = 'O';
				}
				else if(matrix[1][2] == matrix[1][0] && matrix[1][1] != 'O') // ELSE_IF10D
				{
					flag = 1;
					systemChoice = matrix[1][1];
					matrix[1][1] = 'O';
				}
			}
		}
	}

	if(!flag)
	{
		if(matrix[1][1] != 'O')
		{
			flag = 1;
			matrix[1][1] = 'O';
		}
	}

	if(!flag)
		return false;

	system("cls");
	cout << "\nSystem Selected: " << systemChoice << '\n';

	return true;
}