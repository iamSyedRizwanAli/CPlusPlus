#include"Deque.h"

void main()
{
	Deque dq(5);
	Deque dq2;

	dq.insertAtStart(1);
	dq.insertAtStart(2);
	dq.insertAtStart(3);

	dq.display();

	int val;
	dq.removeFromStart(val);

	dq.insertAtStart(6);

	dq.display();

	dq.insertAtEnd(10);
	dq.insertAtEnd(11);

	dq.display();

	dq.removeFromStart(val);

	dq.insertAtStart(15);

	dq.display();
	
	dq2 = dq;

	dq2.display();
}