#ifndef DEQUE_H
#define DEQUE_H

class Deque
{
private:
	int * q;
	int maxSize, currSize;
	int front, back;

	bool isEmpty();
	bool isFull();
public:
	Deque();
	Deque(int size);
	Deque(const Deque & q);
	bool insertAtStart(int val);
	bool insertAtEnd(int val);
	bool removeFromStart(int & val);
	bool removeFromEnd(int & val);
	Deque & operator=(const Deque& dq);
	~Deque();
	void display();
};

#endif