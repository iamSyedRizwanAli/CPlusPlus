#ifndef QUEUE_H
#define QUEUE_H
class Queue
{
	int * q;
	int maxSize, currSize;
	int front, back;

	bool isEmpty();
	bool isFull();
public:
	Queue(int size);
	Queue(const Queue & q);
	bool enqueue(int val);
	bool dequeue(int & val);
	Queue & operator = (const Queue & q1);
	~Queue();
	void display();
};
#endif