#include "Queue.h"
#include<iostream>

Queue ::Queue(int size)
{
	if(size > 0)
	{
		maxSize = size;
		q = new int [size];
		currSize = 0 ;
		front = 0;
		back = -1;
	}
}

Queue :: Queue(const Queue & q1)
{
	maxSize = q1.maxSize;
	front = q1.front;
	back = q1.back;
	currSize = q1.currSize;
	q = new int [maxSize];

	for(int i = 0; i < currSize ; i++)
		q[i] = q1.q[i];
}

bool Queue::isEmpty()
{
	if(currSize == 0)
		return true;
	return false;
}

bool Queue :: isFull()
{
	if(currSize == maxSize)
		return true;
	return false;
}

bool Queue :: enqueue(int val)
{
	if(q)
	{
		if(isFull())
			return false;
		
		back++;

		if(back == maxSize)
		{
			back = 0;
		}

		q[back] = val;
		currSize++;
	
		return true;
	}
	return false;
}

bool Queue :: dequeue(int & val)
{
	if(q)
	{
		if(isEmpty())
			return false;

		val = q[front];
		front++;

		if(front == maxSize)
			front = 0;

		currSize--;

		return true;
	}
	return false;
}

Queue & Queue :: operator = (const Queue & q1)
{
	if(this == & q1)
		return *this;

	if(q)
	{
		this -> ~Queue();
	}

	q = new int [q1.maxSize];

	maxSize = q1.maxSize;
	front = q1.front;
	back = q1.back;
	currSize = q1.currSize;

	for(int i = 0; i < currSize ; i++)
		q[i] = q1.q[i];

	return *this;

}

Queue :: ~Queue()
{
	if(q)
	{
		delete [] q;
		q = 0;
	}
}

void Queue :: display()
{
	int i = front;
	int j = 0;

	for( j ; j < currSize ; j++)
	{
		if(i == maxSize)
			i = 0;

		std :: cout << q[i] << " ";
		i++;
	}
	std :: cout << std :: endl;
}