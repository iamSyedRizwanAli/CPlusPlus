#include "Deque.h"
#include<iostream>

Deque :: Deque()
{
	q = 0;
	maxSize = 0;
	currSize = 0;
	front = 0;
	back = 0;
}

Deque :: Deque(int size)
{
	if(size > 0)
	{
		maxSize = size;
		currSize = 0;
		front = 0;
		back = -1;

		q = new int [size];
	}
}

Deque :: Deque (const Deque & dq)
{
	maxSize = dq.maxSize;
	currSize = dq.currSize;
	front = dq.front;
	back = dq.back;

	q = new int [maxSize];

	for(int i = 0 ; i < currSize ; i++)
		q[i] = dq.q[i];
}

bool Deque::isEmpty()
{
	if(currSize == 0)
		return true;
	return false;
}

bool Deque :: isFull()
{
	if(currSize == maxSize)
		return true;
	return false;
}

bool Deque :: insertAtEnd(int val)
{
	if(q)
	{
		if(isFull())
			return false;

		back++;

		if(back == maxSize)
			back = 0;

		q[back] = val;
		currSize++;

		return true;

	}
	return false;
}

bool Deque :: insertAtStart(int val)
{
	if(q)
	{
		if(isFull())
			return false;

		if(isEmpty())
		{
			back++;
		}
		else if(front == 0)
		{
			front = maxSize - 1;
		}
		else
		{
			front--;
		}
		q[front] = val;
		currSize ++;
		return true;
	}
	return false;
}

bool Deque :: removeFromStart(int & val)
{
	if(q)
	{
		if(isEmpty())
			return false;

		val = q[front];
		front++;

		if(front == maxSize)
			front = 0;

		currSize--;
		return true;
	}
	return false;
}

bool Deque :: removeFromEnd(int & val)
{
	if(q)
	{
		if(isEmpty())
			return false;
		
		val = q[back];
		back --;

		if(back == 0)
			back = maxSize - 1;

		currSize --;
		return true;
	}
	return false;
}


Deque & Deque :: operator=(const Deque& dq)
{
	if(&dq == this)
		return *this;

	if(q)
	{
		this -> ~Deque();
	}
	
	maxSize = dq.maxSize;
	currSize = dq.currSize;
	front = dq.front;
	back = dq.back;

	q = new int [maxSize];

	for(int i = 0 ; i < currSize ; i++)
		q[i] = dq.q[i];

	return *this;
}

Deque :: ~Deque()
{
	if(q)
	{
		delete [] q;
		q = 0;
	}
}

void Deque :: display()
{
	int i = front;
	int j = 0;

	for( j ; j < currSize ; j++)
	{
		if(i == maxSize)
			i = 0;

		std :: cout << q[i] << " ";
		i++;
	}
	std :: cout << std :: endl;
}