#include<iostream>
using namespace std;

int power(const int base, const int exponent)
{
	int temp = 1;
	int count = 1 ;

	while(count <= exponent)
	{
		temp *= 2;
		count ++;
	}

	return temp;
}

float logarithmBase2(const int value)
{
	if(value == 0)
		return -1;
	else if(value == 1)
		return 0;

	int exponentFixed = 0, comparisonValue;

	while(value > power(2, exponentFixed))
	{
		exponentFixed++;
	}

	int temp = power(2, exponentFixed);
	comparisonValue = power(2, exponentFixed - 1);
	//comparisonValue++;

	if(value == temp)
		return exponentFixed;
	else
	{
		exponentFixed--;

		int count = 0, temp2;
		float exponentFloat, deviation, valueAfterLog, difference;

		valueAfterLog = exponentFixed;

		difference = temp - comparisonValue;

		deviation = 1/difference;

		while(comparisonValue < value)
		{
			comparisonValue++;
			count++;
		}

		exponentFloat = count * deviation;

		valueAfterLog += exponentFloat;

		return valueAfterLog;
	}
}

void main()
{

	int value = 1;
	float log;

	cout << "\t\t\tFind the Log base 2 (version 1.0.0)\n\t\tThe program will give the approximate values.\n \t\t\t   Made by Syed Rizwan Ali (c)\n\n";
	
	while(value != 0)
	{
		cout << "Enter value: ";
		cin >> value;
		log = logarithmBase2(value);

		if(log == -1)
			cout << "The log base 2 of " << value << " is infinity.\n";
		else
			cout << "The log base 2 of " << value << " is " << log << '\n';
	}
}