#ifndef STUDENTBST_H
#define STUDENTBST_H

#include<iostream>
using namespace std;

class StudentBST;

class StudentNode
{
	friend class StudentBST;
private:
	int rollNo; // Student�s roll number (must be unique)
	string name; // Student�s name
	double cgpa; // Student�s CGPA
	StudentNode *left; // Pointer to the left subtree of a node
	StudentNode *right; // Pointer to the right subtree of a node
};

class StudentBST 
{
private:
	StudentNode *root; // Pointer to the root node of the tree

	void displayStudent(StudentNode * temp);
	void inOrderDisplay(StudentNode * temp);
	void preOrderDisplay(StudentNode * temp);
	void postOrderDisplay(StudentNode * temp);
	bool search(StudentNode * temp, int & rn);
	void destroy(StudentNode * temp);

	void displayInorderRange(StudentNode *temp, double cgpaStart, double cgpaEnd);
public:
	StudentBST(); // Default constructor
	bool insert(int rn, string n, double c);
	void inOrder();
	void preOrder();
	void postOrder();
	bool search(int rn);
	bool remove(int rn);
	~StudentBST();
	
	void displayRange(double cgpaStart, double cgpaEnd);
private:
	static void menuFunction();
};

#endif