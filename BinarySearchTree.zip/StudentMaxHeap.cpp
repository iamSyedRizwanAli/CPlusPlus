#include"StudentMaxHeap.h"
#include<iostream>
using namespace std;

StudentMaxHeap :: StudentMaxHeap(int size)
{
	if(size)
	{
		st = new Student [size + 1];
		maxSize = size;
		currSize = 0;
	}
	else
	{
		st = 0;
		maxSize = currSize = 0;
	}
}

StudentMaxHeap :: ~StudentMaxHeap()
{
	if(st)
	{
		delete [] st;
		st = 0;
	}
}

bool StudentMaxHeap :: isEmpty()
{
	return currSize == 0 ? true : false;
}

bool StudentMaxHeap :: isFull()
{
	return maxSize == currSize ? true : false;
}

bool StudentMaxHeap :: insert(int rollNo, double cgpa)
{
	if(isFull())
		return false;
	else
	{
		currSize++;
		int i = currSize;
		while( i > 1 && cgpa > st[i/2].cgpa)
		{
			st[i].cgpa = st[i/2].cgpa;
			st[i].rollNo = st[i/2].rollNo;
			i = i / 2;
		}
		while(i > 1 && cgpa == st[i/2].cgpa && rollNo < st[i/2].rollNo)
		{
			st[i].cgpa = st[i/2].cgpa;
			st[i].rollNo = st[i/2].rollNo;
			i = i / 2;
		}
		st[i].cgpa = cgpa;
		st[i].rollNo = rollNo;
		return true;
	}
}

void StudentMaxHeap :: swap(Student & val1, Student & val2)
{
	Student temp = val1;
	val1 = val2;
	val2 = temp;
}

void StudentMaxHeap :: heapify(int i)
{
	int left, right, largest;
	bool flag = 0;

	while(i * 2 <= currSize && !flag)
	{
		left = i * 2;
		right = left + 1;
		largest = i;

		if(st[left].cgpa > st[right].cgpa)
			largest = left;
		if(right <= currSize && st[left].cgpa < st[right].cgpa)
			largest = right;
		if(right <= currSize && st[left].cgpa == st[right].cgpa)
		{
			if(st[left].rollNo > st[right].rollNo)
				largest = right;
			else
				largest = left;
		}

		if(largest != i)
		{
			swap(st[i], st[largest]);
			i = largest;
		}
		else
			flag = 1;
	}
}

bool StudentMaxHeap :: removeBestStudent(int & rollNo, double & cgpa)
{
	if(isEmpty())
		return false;
	else
	{
		rollNo = st[1].rollNo;
		cgpa = st[1].cgpa;
		st[1] = st[currSize];
		currSize--;
		heapify(1);
		return true;
	}
}

int StudentMaxHeap :: height()
{
	if(isEmpty())
		return 0;
	else
		return ceil(log(currSize - 1) / log(2));
}

void StudentMaxHeap :: levelOrder()
{
	for(int i = 1 ; i <= currSize ; i++)
		cout << st[i].rollNo << " : " << st[i].cgpa << '\n';
}