#include "StudentBST.h"
#include <iostream>
#include <string>
using namespace std;

StudentBST :: StudentBST()
{
	root = 0;
}

bool StudentBST :: insert(int rn, string n, double c)
{
	StudentNode * curr = root, *parent = 0;

	while(curr != 0)
	{
		if(rn == curr -> rollNo)
			return false;
		else if(rn < curr -> rollNo)
		{
			parent = curr;
			curr = curr -> left;
		}
		else
		{
			parent = curr;
			curr = curr -> right;
		}
	}

	curr = new StudentNode;
	curr -> rollNo = rn;
	curr -> cgpa = c;
	curr -> name.assign(n);
	curr -> left = curr -> right = 0;

	if(parent == 0)
		root = curr;
	else
	{
		if(parent -> rollNo > rn)
			parent -> left = curr;
		else
			parent -> right = curr;
	}
	return true;
}

void StudentBST :: displayStudent(StudentNode * temp)
{
	cout << "\nRoll Number: " << temp -> rollNo;
	cout << "\nName: " << temp ->name.data();
	cout << "\nCGPA: " << temp -> cgpa << '\n';
}

void StudentBST :: preOrder()
{
	preOrderDisplay(root);	
}

void StudentBST :: preOrderDisplay(StudentNode * temp)
{
	if(temp != 0)
	{
		displayStudent(temp);
		preOrderDisplay(temp -> left);
		preOrderDisplay(temp -> right);
	}
}

void StudentBST :: inOrder()
{
	inOrderDisplay(root);
}

void StudentBST :: inOrderDisplay(StudentNode * temp)
{
	if(temp != 0)
	{
		inOrderDisplay(temp -> left);
		displayStudent(temp);
		inOrderDisplay(temp -> right);
	}
}

bool StudentBST :: search(int rn)
{
	return search(root, rn);
}

bool StudentBST :: search(StudentNode * temp, int &rn)
{
	if(temp != 0)
	{
		if(temp -> rollNo == rn || search(temp -> left,rn) || search(temp -> right, rn))
			return true;
	}
	return false;
}

StudentBST :: ~StudentBST()
{
	destroy(root);
}

void StudentBST :: destroy(StudentNode * temp)
{
	if(temp != 0)
	{
		destroy(temp -> left);
		temp -> left = 0;
		destroy(temp -> right);
		temp -> right = 0 ;

		if(temp -> left == 0 && temp -> right == 0)
			delete temp;
	}
}

bool StudentBST :: remove(int val)
{
	StudentNode* curr = root, *parent = 0;
	while(curr != 0 && curr -> rollNo != val)
	{
		if(val < curr -> rollNo)
		{
			parent = curr;
			curr = curr -> left;
		}
		else
		{
			parent = curr ; 
			curr = curr -> right;
		}
	}
	if(curr == 0)
	{
		return false;
	}
	else
	{
		if(curr -> left != 0 && curr -> right != 0)
		{
			StudentNode * pp = curr;
			StudentNode * pred = curr -> left;
			while(pred->right != 0)
			{
				pp = pred;
				pred = pred -> right;
			}
			(*curr) = (*pred);
			parent = pp;
			curr = pred;
		}
		if(curr == root)
		{
			if(root -> left != 0)
				root = root -> left;
			else
				root = root -> right;
			delete curr;
			curr = 0;
			return true;
		}
		else
		{
			StudentNode* temp;
			if(curr -> left != 0)
				temp = curr -> left;
			else
				temp = curr -> right;

			if(curr == parent -> left)
				parent -> left = temp;
			else
				parent -> right = temp;

			delete curr;
			curr = 0;
			return true;
		}
	}
}

void StudentBST :: postOrderDisplay(StudentNode * temp)
{
	if(temp != 0)
	{
		postOrderDisplay(temp -> right);
		displayStudent(temp);
		postOrderDisplay(temp -> left);
	}
}

void StudentBST :: postOrder()
{
	postOrderDisplay(root);
}

void StudentBST :: menuFunction()
{
	StudentBST catalogue;

	int choice = 0;

	while(choice != 7)
	{
		cout << "\n1. Insert a new student\n2. Search for a student\n3. See the list of all students\n4. Remove a student\n5. See preOrder Display: \n6. See postOrder Display: \n7. Quit\n\nEnter your choice: ";
		cin >> choice;

		switch(choice)
		{
		case 1:
			{
				int rollNo;
				string name;
				double cgpa;
				cout << "Enter Roll number: ";
				cin >> rollNo;
				cin.ignore();
				cout << "Enter Name: ";
				getline(cin, name);
				cout << "Enter CGPA: ";
				cin >> cgpa;
				cin.ignore();

				system("cls");

				if(catalogue.insert(rollNo, name, cgpa))
					cout << "\nStudent insertion succeed\n";
				else
					cout << "\nStudent insertion failed\n";
			}
			break;
		case 2:
			{
				int rollNo;
				cout << "Enter Roll number: ";
				cin >> rollNo;

				system("cls");

				if(catalogue.search(rollNo))
					cout << "\nStudent found\n";
				else
					cout << "\nError 404 - Student not found\n";
			}
			break;
		case 3:
			{
				system("cls");
				catalogue.inOrder();
				cout << '\n';
			}
			break;
		case 4:
			{
				int rollNo;
				cout << "\nEnter Roll Number: ";
				cin >> rollNo;

				system("cls");

				if(catalogue.remove(rollNo))
					cout << "\nStudent found and removed\n";
				else
					cout << "\nStudent not found\n";
			}
			break;
		case 5:
			{
				system("cls");
				catalogue.preOrder();
				cout << '\n';
			}
			break;
		case 6:
			{
				system("cls");
				catalogue.postOrder();
				cout << '\n';
			}
			break;
		}
	}
}

void StudentBST :: displayRange(double cgpaStart, double cgpaEnd)
{
	displayInorderRange(root,cgpaStart,cgpaEnd);
}

void StudentBST :: displayInorderRange(StudentNode *temp, double cStart, double cEnd)
{
	if(temp != 0)
	{
		
		displayInorderRange(root ->  left, cStart, cEnd);
		
		if(temp -> cgpa >= cStart || temp -> cgpa <= cEnd)
			displayStudent(temp);
		
		displayInorderRange(root ->  right, cStart, cEnd);
	}

}

