#ifndef STUDENTMAXHEAP_H
#define STUDENTMAXHEAP_H

class StudentMaxHeap;

class Student 
{
	friend class StudentMaxHeap;

private:

	double cgpa; // Student�s CGPA
	int rollNo; // Student�s roll number
};

class StudentMaxHeap 
{
private:

	Student* st; // Array of students which will be arranged like a Max Heap
	int currSize; // Current number of students present in the heap
	int maxSize; // Maximum number of students that can be present in the heap

	void heapify(int i);
	void swap(Student & val1, Student & val2);

public:

	StudentMaxHeap (int size); // Constructor
	~StudentMaxHeap(); // Destructor
	bool isEmpty(); // Checks whether the heap is empty or not
	bool isFull(); // Checks whether the heap is full or not

	bool insert(int rollNo, double cgpa);
	bool removeBestStudent(int & rollNo, double & cgpa);
	void levelOrder();
	int height();
};

#endif