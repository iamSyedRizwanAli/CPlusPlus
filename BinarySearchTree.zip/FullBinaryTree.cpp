#include "FullBinaryTree.h"
#include <iostream>
using namespace std;

FullBinaryTree :: FullBinaryTree(int n)
{
	if(n > 0)
	{
		treeSize = pow(2, ceil(log(n)/log(2)) + 1) - 1;
		tree = new int [treeSize];

		for(int i = 0 ; i < treeSize ; i++)
			tree[i] = 0;

		sortSize = n;
		sorted = new int [sortSize];

		for(int i = 0 ; i < sortSize ; i++)
			sorted[i] = 0;
		E = n;
	}
	else
	{
		tree = sorted = 0;
		treeSize = sortSize = 0;
		E = -999;
	}
}

void FullBinaryTree :: loadValues(int * arr, int n)
{
	int i = treeSize / 2;
	int size = treeSize - i;
	int count = 0;
	int maxValueIndex = arr[0];
	for( i ; i < treeSize && count < n ; i++)
	{
		if(arr[count] > arr[maxValueIndex])
			maxValueIndex = count;

		tree[i] = arr[count];
		count++;
	}

	E = arr[maxValueIndex] + 1;

	while(i < treeSize)
	{
		tree[i] = E;
		i++;
	}
}

void FullBinaryTree :: sortValues()
{
	if(E != -999)
	{
		int height = log(treeSize + 1) / log(2);
		int baseLevel = height; // <---<<<
		int nodesInUpperLevel, commonParentToFirstChildDistance, counter, startingNodeofBaseLevel, tempSize;
		int counterOfSortedArray = 0;
		tempSize = treeSize;

		while(tree[0] != E && counterOfSortedArray < sortSize)
		{
			while(baseLevel != 1)
			{
				nodesInUpperLevel = pow(2, baseLevel - 2);
				commonParentToFirstChildDistance = nodesInUpperLevel;

				startingNodeofBaseLevel = tempSize / 2;
				counter = 0;
				int i = startingNodeofBaseLevel;

				while(counter < nodesInUpperLevel && i < tempSize)
				{
					if(tree[i] <= tree [i + 1])
					{
						tree[i - (commonParentToFirstChildDistance + counter)] = tree[i];
					}
					else
					{
						tree[i - (commonParentToFirstChildDistance + counter)] = tree[i+1];
					}

					i += 2;
					counter ++;
				}

				counter = 0;
				tempSize = startingNodeofBaseLevel - 1;
				baseLevel --;
			}

			display(1);

			replaceFirstOccurrence(tree[0] , E);

			sorted[counterOfSortedArray] = tree[0];
			counterOfSortedArray++;

			baseLevel = height;
			tempSize = treeSize;
		}
		display(0);
	}
}

bool FullBinaryTree :: replaceFirstOccurrence(int value1, int value2)
{
	int i = treeSize / 2;

	while( i < treeSize)
	{
		if(tree[i] == value1)
		{
			tree[i] = value2;
			return true;
		}
		i++;
	}
	return false;

}

void FullBinaryTree :: display(bool arr)
{
	int *arra, size;
	if(arr)
	{
		arra = tree;
		size = treeSize;
	}
	else
	{
		arra = sorted;
		size = sortSize;
	}

	for(int i = 0 ; i < size ; i++)
		cout << arra[i] << ' ';
	cout << endl;
}

FullBinaryTree :: ~FullBinaryTree()
{
	if(tree)
	{
		delete [] tree;
		tree = 0;
	}
	if(sorted)
	{
		delete [] sorted;
		sorted = 0;
	}
}