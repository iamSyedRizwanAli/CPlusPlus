#include"BST.h"
#include<iostream>
#include"StudentBST.h"
#include"FullBinaryTree.h"
#include"StudentMaxHeap.h"
using namespace std;

void main()
{
	/*FullBinaryTree tree(5);
	int arr [5] = {8, 20, 41, 7, 2};
	tree.loadValues(arr, 5);
	tree.sortValues();*/

	//StudentBST ::menuFunction();

	BST tree;

	tree.insert(5);
	tree.insert(3);
	tree.insert(7);
	tree.insert(4);
	tree.insert(2);
	tree.insert(6);
	tree.insert(1);
	tree.insert(8);
	tree.insert(0);

	tree.printAllPaths();

	/*int arr[10] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
	tree.createBalancedTree(arr, 0, 9);

	tree.inOrder();
	cout << '\n';
	tree.preOrder();
	cout << '\n';
	tree.postOrder();*/

	/*StudentMaxHeap smh(5);

	smh.insert(3, 3.4);
	smh.insert(6, 4);
	smh.insert(1, 4);
	smh.insert(45, 2.7);
	smh.insert(12, 3.1);

	smh.levelOrder();

	double a;
	int b;

	smh.removeBestStudent(b,a);

	cout << '\n';

	smh.levelOrder();
*/
}