#ifndef FULLBINARYTREE_H
#define FULLBINARYTREE_H

class FullBinaryTree
{
private:
	int * tree;
	int treeSize;
	int * sorted;
	int sortSize;
	int E;

	void display(bool arr);
	bool replaceFirstOccurrence(int value1, int value2);
public:
	FullBinaryTree(int n);
	void loadValues(int* arr, int n);
	void sortValues();
	~FullBinaryTree();
};

#endif