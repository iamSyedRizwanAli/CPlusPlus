#ifndef BST_H
#define BST_H

class BST;

class TreeNode
{
	friend class BST;
private:
	int data;
	TreeNode* left;
	TreeNode* right;	
};

class BST
{
private:
	TreeNode * root;

	void inOrder(TreeNode * temp);
	void preOrder(TreeNode *temp);
	void postOrder(TreeNode * temp);

	bool search(TreeNode * temp, int & val);
	void remove(TreeNode * temp);

	bool isEqual(const TreeNode * node1, const TreeNode * node2);
	TreeNode * copy(const TreeNode * origNode);
	bool doubleInsert(int val);
	void doubleTree(BST & tree, TreeNode * temp);
	int countNodes(TreeNode * temp);

	void printPath(int * arr, int n);
	void traversePath(int * arr, int n, TreeNode * temp);
	int getHeight(TreeNode * temp);
	void creatingBalancedTree(int * arr, int start, int end);
public:
	BST();
	BST(const BST & tree);
	bool search(int val);
	void inOrder();
	void preOrder();
	void postOrder();
	bool insert(int val);
	bool remove(int val);
	void doubleTree();
	~BST();

	int countNodes();
	bool operator ==(const BST & tree);
	BST & operator = (const BST & tree);
	void printAllPaths();


	int getHeight();
	void createBalancedTree(int * arr, int start, int end);
};

#endif