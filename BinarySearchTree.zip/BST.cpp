#include "BST.h"
#include <iostream>
using namespace std;

BST :: BST()
{
	root = 0;
}

void BST :: doubleTree()
{
	BST tempTree;
	doubleTree(tempTree, root);

	this -> ~BST();

	root = tempTree.root;
	tempTree.root = 0;
}

void BST :: doubleTree(BST & tree, TreeNode * temp)
{
	if(temp != 0)
	{
		tree.insert(temp -> data);
		tree.doubleInsert(temp -> data);

		doubleTree(tree, temp -> left);
		doubleTree(tree, temp -> right);
	}
}

bool BST :: doubleInsert(int val)
{
	TreeNode * curr = root, *parent = 0;

	while(curr != 0 || parent -> data != val)
	{
		if(val <= curr -> data)
		{
			parent = curr;
			curr = curr -> left;
		}
		else
		{
			parent = curr;
			curr = curr -> right;
		}
	}
	curr = new TreeNode;
	curr -> data = val;
	curr -> left = curr -> right = 0;
	if(parent == 0)
		root = curr;
	else
	{
		if(parent -> data >= val)
			parent -> left = curr;
		else
			parent -> right = curr;
	}
	return true;
}


bool BST :: insert(int val)
{
	TreeNode * curr = root, *parent = 0;

	while(curr != 0)
	{
		if(val == curr -> data)
			return false;
		else if(val < curr -> data)
		{
			parent = curr;
			curr = curr -> left;
		}
		else
		{
			parent = curr;
			curr = curr -> right;
		}
	}
	curr = new TreeNode;
	curr -> data = val;
	curr -> left = curr -> right = 0;
	if(parent == 0)
		root = curr;
	else
	{
		if(parent -> data > val)
			parent -> left = curr;
		else
			parent -> right = curr;
	}
	return true;
}

bool BST :: remove(int val)
{
	TreeNode* curr = root, *parent = 0;
	while(curr != 0 && curr -> data != val)
	{
		if(val < curr -> data)
		{
			parent = curr;
			curr = curr -> left;
		}
		else
		{
			parent = curr ; 
			curr = curr -> right;
		}
	}
	if(curr == 0)
	{
		return false;
	}
	else
	{
		if(curr -> left != 0 && curr -> right != 0)
		{
			TreeNode * pp = curr;
			TreeNode * pred = curr -> left;
			while(pred->right != 0)
			{
				pp = pred;
				pred = pred -> right;
			}
			curr -> data = pred -> data;
			parent = pp;
			curr = pred;
		}
		if(curr == root)
		{
			if(root -> left != 0)
				root = root -> left;
			else
				root = root -> right;
			delete curr;
			curr = 0;
			return true;
		}
		else
		{
			TreeNode* temp;
			if(curr -> left != 0)
				temp = curr -> left;
			else
				temp = curr -> right;

			if(curr == parent -> left)
				parent -> left = temp;
			else
				parent -> right = temp;

			delete curr;
			curr = 0;
			return true;
		}
	}
}

void BST::preOrder()
{
	preOrder(root);
}

void BST ::preOrder(TreeNode * temp)
{
	if(temp != 0)
	{
		cout << temp -> data << ' ';
		preOrder(temp ->left);
		preOrder(temp -> right);
	}
}

void BST::inOrder()
{
	inOrder(root);
}

void BST::inOrder(TreeNode * temp)
{
	if(temp != 0)
	{
		inOrder(temp -> left);
		cout << temp -> data << ' ';
		inOrder(temp -> right);
	}
}

void BST :: postOrder()
{
	postOrder(root);
}

void BST:: postOrder(TreeNode * temp)
{
	if(temp != 0)
	{
		postOrder(temp -> right);
		cout << temp -> data << ' '; 
		postOrder(temp -> left);
	}
}

bool BST:: search(int val)
{
	return search(root, val);
}

bool BST :: search(TreeNode * temp, int &val)
{
	if(temp != 0)
	{
		if(temp -> data == val || search(temp -> left,val) || search(temp -> right, val))
			return true;
	}
	else
		return false;
	return false;
}

int BST :: countNodes()
{
	return countNodes(root);
}

int BST :: countNodes(TreeNode * temp)
{
	if(temp != 0)
	{
		return countNodes(temp -> left) + countNodes(temp -> right) + 1;
	}
	else
		return 0;
}

BST :: ~BST()
{
	remove(root);
	root = 0;
}

void BST :: remove(TreeNode * temp)
{
	if(temp != 0)
	{
		remove(temp -> left);
		temp -> left = 0;
		remove(temp -> right);
		temp -> right = 0;

		if(temp -> right == 0 && temp -> left == 0)
			delete temp;
	}
}

bool BST :: operator==(const BST & tree)
{
	if(this == &tree)
		return true;
	else
		return isEqual(root, tree.root);
}

bool BST :: isEqual(const TreeNode * node1, const TreeNode * node2)
{
	if(!node1 && !node2)
		return true;
	if(node1 && node2 && node1 -> data == node2 -> data && isEqual(node1 -> left, node2 -> left) && isEqual(node1-> right, node2 -> right))
		return true;
	else
		return false;
}

BST :: BST(const BST & tree)
{
	root = copy(tree.root);
}

TreeNode * BST :: copy(const TreeNode * origNode)
{
	if(origNode)
	{
		TreeNode * temp = new TreeNode;
		temp -> data = origNode -> data;
		temp -> left = copy(origNode -> left);
		temp -> right = copy(origNode -> right);
		return temp;
	}
	else 
		return 0;
}

BST & BST :: operator = (const BST & tree)
{
	if(this == &tree)
		return *this;

	if(root)
		this -> ~BST();

	root = copy(tree.root);

	return *this;
}

void BST :: printAllPaths()
{
	int numberofNodes = countNodes();
	int size = ceil(log(numberofNodes) / log(2));

	int * arr = new int [size + 1];

	traversePath(arr, 0, root);

	delete [] arr;
}

void BST :: traversePath(int * arr, int n , TreeNode  * temp)
{
	if(temp != 0)
	{
		arr[n] = temp -> data;
		traversePath(arr, n + 1, temp -> left);

		if(temp -> right!= 0)
			traversePath(arr, n + 1, temp -> right);
	}
	else
		printPath(arr, n);
}

void BST :: printPath(int * arr, int n)
{
	int i = 0;
	while( i < n)
	{
		cout << arr[i];
		i++;
		if(i < n)
			cout << " -> ";
	}
	cout << endl;
}

int BST :: getHeight()
{
	return getHeight(root);
}

int BST :: getHeight(TreeNode * temp)
{
	if(temp != 0)
	{
		if(getHeight(temp -> left) + 1 > getHeight(temp -> right) + 1)
			return getHeight(temp -> left) + 1;
		else
			return getHeight(temp -> right) + 1;
	}
	return 0;
}

void BST :: createBalancedTree(int * arr, int start, int end)
{
	if(root)
		this -> ~BST();

	creatingBalancedTree(arr, start, end);

}

void BST :: creatingBalancedTree(int * arr, int start, int end)
{
	if(start <= end)
	{
		insert(arr[(start + end) / 2]);
		creatingBalancedTree(arr, start, ((start + end) / 2) - 1);
		creatingBalancedTree(arr, ((start + end) / 2) + 1, end); 
	}
}