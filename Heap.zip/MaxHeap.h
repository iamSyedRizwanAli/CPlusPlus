#ifndef MAXHEAP_H
#define MAXHEAP_H

class MaxHeap
{
private:

	int * arr;
	int maxSize,
		currSize;
	
	bool isFull();
	bool isEmpty();
	void swap(int & val1, int & val2);
	void heapify(int i);
public:

	MaxHeap(int n = 0);
	MaxHeap(const MaxHeap & heap);
	bool insert(int val);
	bool removeMax(int & max);
	MaxHeap & operator = (const MaxHeap & heap);
	void display();
	void buildHeap(int * arr, int size);
	~MaxHeap();
};

#endif