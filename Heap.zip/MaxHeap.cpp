#include "MaxHeap.h"
#include <iostream>
using namespace std;

MaxHeap :: MaxHeap(int size)
{
	if(size > 0)
	{
		arr = new int [size + 1];
		maxSize = size;
		currSize = 0;
	}
	else
	{
		arr = 0;
		maxSize = currSize = 0;
	}
}

MaxHeap :: MaxHeap(const MaxHeap & heap)
{
	if(heap.arr)
	{
		maxSize = heap.maxSize;
		currSize = heap.currSize;

		arr = new int [maxSize];

		for(int i = 0 ; i < currSize ; i++)
			arr[i] = heap.arr[i];

	}
	else
	{
		arr = 0;
		maxSize = currSize = 0;
	}
}

void MaxHeap :: swap(int & val1, int & val2)
{
	int temp = val1;
	val1 = val2;
	val2 = temp;
}

bool MaxHeap :: isEmpty()
{
	return currSize == 0 ? true : false;
}

bool MaxHeap :: isFull()
{
	return currSize == maxSize ? true : false;
}

bool MaxHeap :: insert(int val)
{
	if(isFull())
		return false;
	else
	{
		currSize++;
		int i = currSize;

		while(i > 1 && arr[i/2] < val)
		{
			arr[i] = arr[i/2];
			i = i/2;
		}
		arr[i] = val;
		return true;
	}

	return true;
}

void MaxHeap :: heapify(int i)
{
	int left, right, largest;
	bool flag = 0;

	while(i * 2 <= currSize && !flag)
	{
		left = i * 2;
		right = left + 1;
		largest = i;

		if(arr[largest] < arr[left] || arr[largest] < arr[right])
		{
			if(arr[left] > arr[right])
				largest = left;
			if(right <= currSize && arr[left] < arr[right])
				largest = right;
	
			if(largest != i)
			{
				swap(arr[i], arr[largest]);
				i = largest;
			}
			else
				flag = 1;
		}
		else
			flag = 1;
	}
}

bool MaxHeap :: removeMax (int & max)
{
	if(isEmpty())
		return false;
	else
	{
		max = arr[1];
		arr[1] = arr[currSize];
		currSize--;

		heapify(1);
		return true;
	}
	return true;
}

MaxHeap & MaxHeap :: operator=(const MaxHeap & heap)
{
	if(&heap == this)
		return *this;

	if(arr)
		this -> ~MaxHeap();

	MaxHeap temp(heap);

	arr = temp.arr;
	maxSize = heap.maxSize;
	currSize = heap.currSize;
	temp.arr = 0;

	return *this;
}

MaxHeap :: ~MaxHeap()
{
	if(arr)
	{
		delete [] arr;
	}
}

void MaxHeap :: display()
{
	for(int i = 1 ; i <= currSize ; i++)
		cout << arr[i] << ' ';
	cout << endl;
}

void MaxHeap :: buildHeap(int * array, int size)
{
	if(arr)
	{
		delete [] arr;
		arr = 0;
	}
	arr = new int [size + 1];
	
	for(int i = 0 ; i < size ; i++)
		arr[i+1] = array[i];

	currSize = maxSize = size;

	for(int i = size / 2; i >= 1 ; i--)
		heapify(i);
}

//void MaxHeap :: buildHeap(int * array, int size)
//{
//	if(arr)
//	{
//		delete [] arr;
//		arr = 0;
//	}
//	currSize = 0;
//	maxSize = size;
//	
//	arr = new int [size + 1];
//	
//	for(int i = 0 ; i < size ; i++)
//		insert(array[i]);
//}