#include "MaxHeap.h"

void main()
{
	MaxHeap h1;

	/*h1.insert(12);
	h1.insert(10);
	h1.insert(9);

	h1.insert(13);
	h1.insert(3);
	h1.insert(15);
	h1.insert(2);*/

	int arr[7] = {12,10,9,13,3,15,2};
	
	h1.buildHeap(arr,7);

	int val;
	//h1.removeMax(val);

	h1.display();
}