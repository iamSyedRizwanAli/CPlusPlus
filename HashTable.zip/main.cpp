#include <iostream>
#include "HashTable.h"

void main()
{
	HashTable hash(10);

	hash.insert("Rizwan");
	hash.insert("Ali");
	hash.insert("Razia");
	hash.remove("Razia");
	hash.display();
}