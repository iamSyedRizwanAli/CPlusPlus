#include<iostream>
#include"HashTable.h"
using namespace std;

HashTable :: HashTable(int size)
{
	if(size)
	{
		table = new string [size];
		S = size;
		n = 0;

		for(int i = 0 ; i < size ; i ++)
			table[i].assign("-1");

	}
	else
	{
		table = 0;
		S = n = 0;
	}
}

HashTable :: ~HashTable()
{
	if(table)
	{
		delete [] table;
		table = 0;
	}
}

bool HashTable :: isEmpty()
{
	return n == 0 ? true : false;
}

bool HashTable :: isFull()
{
	return n == S ? true : false;
}

double HashTable :: loadFactor()
{
	return (n/S);
}

int HashTable :: getHashValue(string name)
{
	int temp = 0;
	for(int i = 0 ; i < name.length() ; i++)
		temp += name[i];
	return temp;
}

bool HashTable :: insert(string name)
{
	int value = getHashValue(name);

	int index = value % S;
	int count = 0;
	bool flag = false;
	

	while(count != S && !flag)
	{
		cout << index << ", ";

		if(table[index].data()[0] == '-' && (table[index].data()[1] == '1' || table[index].data()[1] == '2'))
		{
			table[index].assign(name);
			flag = 1;
			n++;
		}
		else
		{			
			index = (index + 1) % S;
			count++;
		}
	}
	cout << '\n';

	return flag;
}

bool HashTable :: search(string name)
{
	int value = getHashValue(name);

	int index = value % S;
	int count = 0;
	bool flag = false;

	while(count != S && !flag && !(table[index].data()[0] == '-' && table[index].data()[1] == '1'))
	{
		cout << index << ", ";

		if(table[index].data() == name.data())
			flag = 1;
		else
		{
			count ++;
			index = ( index + 1 ) % S;
		}
	}

	cout << '\n';

	return flag;
}

void HashTable :: display()
{
	int i = 0 ; 

	while(i != S)
	{
		if(table[i].data()[0] == '-' && (table[i].data()[1] == '1' || table[i].data()[1] == '2'))
			cout << "EMPTY\n";
		else
			cout << table[i].data() << '\n';
		i++;
	}
}

bool HashTable :: remove(string name)
{
	int value = getHashValue(name);

	int index = value % S;
	int count = 0;
	bool flag = false;

	while(count != S && !flag && !(table[index].data()[0] == '-' && table[index].data()[1] == '1'))
	{
		cout << index << ", ";

		if(table[index].data() == name.data())
		{
			table[index].assign("-2");
			flag = 1;
			n--;
		}
		else
		{
			count ++;
			index = ( index + 1 ) % S;
		}
	}

	cout << '\n';

	return flag;
}



//void HashTable :: menuDriven()
//{
//	int size;
//	cout << "Enter the size of Hash Table: ";
//	cin >> size;
//
//	HashTable tab(size);
//	
//	int choice = 0;
//
//	while(choice != 6)
//	{
//		cout << "\n1. Insert a name\n2. Search for a name\n3. Remove a name\n4. Display the Hash Table\n5. Display Load Factor of the table\n6. Exit\n\nEnter your choice: ";
//		cin >> choice;
//
//		switch(choice)
//		{
//		case 1:
//			{
//				
//			}
//			break;
//		case 2:
//			{
//
//			}
//			break;
//		case 3:
//			{
//
//			}
//			break;
//		case 4:
//			{
//
//			}
//			break;
//		case 5:
//			{
//
//			}
//			break;
//		case 6:
//			{
//					
//			}
//			break;
//		}
//	}
//}