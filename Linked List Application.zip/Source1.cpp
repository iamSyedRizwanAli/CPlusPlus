// Syed Rizwan Ali
// BSEF14A049
// BSE-F14-AFTERNOON

//////////////////////////////////ASSIGNMENT STARTS FROM HERE///////////////////////////////

#include<iostream>
using namespace std;

//////////////////////////////////////////LINKED LIST CLASS///////////////////////////////

class LinkedList;

class Node
{
	friend class LinkedList;
private:
	int data;
	Node * next;
};

class LinkedList
{
private:
	Node * l;				// left pointer
	Node * r;				// right pointer
	
	int countNodes(Node * ptr);		// this function counts number of nodes in a segment of linked list

public:
	LinkedList();			//Constructor
	void moveRight(int n);
	void moveLeft(int n);
	bool isEmpty();
	void printLeft();
	void printRight();
	bool insert(int val);
	bool remove(int val);
	~LinkedList();			//Destructor
};

bool LinkedList :: isEmpty()
{
	if(l == r && r == 0) // if both left and right pointers are pointing to NULL
		return true;
	else
		return false;
}

LinkedList :: LinkedList()
{
	l = r = 0; // intializing left and right pointer to NULL
}

bool LinkedList :: insert(int val)
{
	Node * temp = new Node; // creating a new Node
	temp -> data = val;		// initializing the data part of new node

	if(isEmpty())			// checking whether the linked list is empty or not
	{
		l = temp;			// pointing left pointer to newly formed/created node
		temp -> next = 0;			// pointing next of newly formed node to NULL
	}
	else
	{
		Node * curr;		// a new node pointer current

		if(l == 0 || (r != 0 && r -> data <= val))			// checking wheter left pointer is NULL or not with OR condition that if value present in the node where right is point less than new value.
		{
			
			curr = r;								// in this segment of condition, the value will placed in the right segment (i.e.; to the right of right pointer)

			while(curr != 0 && curr -> data < val)	// since, we are going in ascending order. Therefore, the check must be placed to see that the upcoming value is lesser than the the value to be inserted. So, the loop could iterate.
			{
				curr = curr -> next;				// jumping current to the next node of right pointer
				r -> next = l;						// updating next of right pointer node to node of left pointer. (i.e.; the previous node)
				l = r;								// taking left pointer one step/node forward
				r = curr;							// pointinf right pointer to the node where current is pointing. (i.e.; the very next node at right side of right pointer)
			}
			
			temp -> next = l;						// pointing next of new node to node of left pointer
			l = temp;								// pointing left pointer to new node

			return true;
		}
		else if(r == 0 || ( r != 0 && r -> data > val))	// checking whether right pointer is NULL or not with OR condition that if value present in the node where right is point greater than new value.
		{
				
			curr = l;								// in this segment of condition the value will be placed in the left segment (i.e.; to the left of left pointer )			

			while(curr != 0 && curr -> data > val)	// since, we are going in descending order. Therefore, the check must be placed to see that the upcoming value is greater than the value to be inserted. So, the loop could iterate.
			{										
				curr = curr -> next;				// jumping to the previous node of the left pointer
				l -> next = r;						// updating next of left pointer node to node of right pointer. (i.e.; the next node)
				r = l;								// taking right pointer one step/node backwards
				l = curr;							// pointing left pointer to the node where current pointer is pointing. (i.e.; the very next node at left side of left pointer)
			}
			
			temp -> next = curr;					// pointing next of new node to current pointer
			l = temp;								// pointing left pointer to new pointer
			
			return true;
		}
	}

	return true;
}

bool LinkedList :: remove(int val)
{
	if(isEmpty())
		return false;
	else
	{

		Node * curr;

		if(l == 0 || (r != 0 && r -> data <= val))   // this condition tells that the value will be searched and removed in the segment right to the right pointer.
		{
			curr = r;					// initializing current pointer to value right poiner, which is that obejctive value has to be in right side of ride pointer

			while(curr != 0 && curr -> data < val) // this loop checks the presence of the value to be deleted
			{
				curr = curr -> next;
			}

			if(curr == 0 || curr -> data != val) // if the value is not present then the linked list will not be disturbed and simply false will be returned
				return false;
			else								 // else if the value is present then changes are made in linked list.
			{
				curr = r;							// initializing current with right pointer, so the value is in right side of right pointer

				while(curr != 0 && curr -> data != val) // this loop will make changes in positions of left and right pointers respective to the position of node having specified value
				{
					curr = curr -> next;			// the whole loop is same as that in insert function
					r -> next = l;
					l = r;
					r = curr;
				}									// in the end of the loop the current pointer will be pointing to the node to be deleted
				
				r = curr -> next;					// pointing right pointer to the next node of the node which is going to be deleted

				delete curr;						// node deleted
				curr = 0;
				return true;
			}

		}
		else if(r == 0 || r -> data > val) // this condition tells that the value will be searched and removed in the segment left to the left pointer.
		{
			curr = l;								// initializing current with left pointer, which means the value has to be in the left side of left pointer

			while(curr != 0 && curr -> data > val)  // this loop will find whether value is present in the linked list
			{
				curr = curr -> next;
			}

			if(curr == 0 || curr -> data != val)	// if objective value is not present in the linked list, then no changes will be made in linked list and simply false will be returned
				return false;
			else									// if required value is present in the linked list then changes will be made in positions of left and right pointers with respect to the position of required node.
			{
				curr = l;							// poiniting current to left pointer, which means value is in the left side of left pointer

				while(curr != 0 && curr -> data > val)
				{
					curr = curr -> next;			// this loop works same as written in the insert function
					l -> next = r;
					r = l;
					l = curr;						
				}									// in the end of loop current will be present on the node which is to be deleted	
				
				l = curr -> next;					// pointing left pointer to the very left node of the node which is to be deleted

				delete curr;
				curr = 0;
				return true;
			}

		}
	}
}

void LinkedList :: printLeft()
{
	if(l != 0)				// checking whether left pointer points to any segment of linked list
	{
		Node * curr = l;	

		while(curr != 0)	// iterating the loop until current pointer reaches to NULL
		{
			cout << curr -> data << ' ';
			curr = curr -> next;
		}
	}
}

void LinkedList :: printRight()
{
	if(r != 0)				// checking whether right pointer points to any segment of linked list
	{
		Node * curr = r;

		while( curr != 0)	// iterating loop until current pointer reaches to NULL
		{
			cout << curr -> data << ' ';
			curr = curr -> next;
		}
	}
}

int LinkedList :: countNodes(Node * ptr)
{
	Node * t = ptr;
	int size = 0;			// an integer variable for saving total number of nodes before left pointer or afterwards right pointer

	while(t != 0)			// this loop will iterate the N times, where N is the number of nodes present beyond right pointer or before left pointer
	{
		t = t -> next;
		size ++;			// increment in size
	}

	return size;			// returning size
}

void LinkedList :: moveRight(int val)
{
	int numberOfNode = countNodes(r); // a variable having total numbers of nodes present after right pointer

	int i = 0;

	Node * curr = r;		 

	while(i < numberOfNode && i < val) // this loop will terminate when either number of nodes are less then value passed or when value passed in parameter is less than number of nodes 
	{
		curr = curr -> next;
		r -> next = l;
		l = r;
		r = curr;
		i++;
	}

}

void LinkedList :: moveLeft(int val)
{
	int numberOfNodes = countNodes(l); // a variable having total number of nodes present before left pointer

	int i = 0;

	Node * curr = l;

	while(i < numberOfNodes && i < val) // this loop will terminate when either number of nodes are less then value passed or when value passed in parameter is less than number of nodes 
	{
		curr = curr -> next;
		l -> next = r;
		r = l;
		l = curr;
		i++;
	}
}

LinkedList :: ~LinkedList()
{
	if(l != 0 || r != 0) // this function will deallocate memory if left pointer or right pointer is not NULL or both are not NULL
	{
		Node * temp = l;

		while( l != 0)		 // this loop will iterate till left pointer will not be NULL
		{
			temp = l;		// pointing temporary node pointer to left pointer
			l = l -> next;	// taking left pointer to previous node

			delete temp;    // node deleted
			temp = 0;
		}

		temp = r;
		while( r != 0 )		// this loop will iterate till right pointer will not be NULL
		{
			temp = r;		// pointing temporary node pointer to right pointer
			r = r -> next;  // taking right pointer to next node

			delete temp;		// node deleted
			temp = 0;
		}
	}
}

//////////////////////////////////////////DRIVER FUNCTION, MAIN and extra added class/////////////////////////////

void driverLinkedList()
{
	LinkedList l1;

	int choice = 9;
	while(choice != 0)
	{
		cout << "\n Enter 1 = For knowing whether list is empty or not"     // this option will call isEmpty() function
			<< "\n Enter 2 = For adding contents in Linked List "			// this option will call bool insert(int val) function
			<< "\n Enter 3 = For removing any content from Linked List"		// this option will call bool remove(int val) function
			<< "\n Enter 4 = For moving the right pointer rightwards "		// this option will call moveRight(int num) function
			<< "\n Enter 5 = For moving the left pointer leftwards"			// this option will call moveLeft(int num) function
			<< "\n Enter 6 = For displaying list "			// this will opt the user with choice to display right or display left
			<< "\n Enter 7 = For removing all of the elements in Linked List "// this option will call the fsdestructor
			<< "\n Enter 0 = For exiting application\n Enter Your Choice:";	// this option will terminate the program

		cin >> choice;
		
		//In all options excluding option 1 and 0; each of them has option to return to main menu without likely enter -999 in most cases
		// doing something, this option is added because user may enter a wrong in main menu, which will call the corresponding function
		// So, user must have choice. To do some changes or not

		switch(choice)
		{
		case 1: //Enter 1 = For knowing whether list is empty or not
			{
				system("cls");

				if(l1.isEmpty())
				{
					cout << "Linked List is Empty\n";
				}
				else
				{
					cout << "Linked List is not Empty\n";
				}
			}
			break;
		case 2: //Enter 2 = For adding contents in Linked List
			{
				int num;
				cout << "\n\tEnter -999 to return to main menu or " // for returning to main menu
					<< "\n\tEnter the value, you want to insert: "; // for inserting a value
				cin >> num;

				
				system("cls");

				if(num != -999) // if user wants to make changes
				{
					if(l1.insert(num))
						cout << "\nStatus: Value added successfully\n";
				}
			}
			break;
		case 3: //Enter 3 = For removing any content from Linked List
			{
				int num;
				cout << "\n\tEnter -999 to return to main menu or " // returning to main menu
					<<"\n\tEnter the value, you want to remove: "; //for removal of some specified value
				cin >> num;

				system("cls");

				if(num != -999) // if user wants to make changes
				{
					if(l1.remove(num))
						cout << "\nStatus: Value removed successfully\n";
					else
						cout << "\nStatus: Value not removed\n";
				}
			}
			break;
		case 4: //Enter 4 = For moving the right pointer rightwards
			{
				int num;

				cout << "\n\tEnter -999 to return to main menu or " // for returning to main menu
					<< "\n\tEnter the number of nodes you want to move right pointer rightwards: "; // for altering the position of right pointer
				cin >> num;

				if(num != -999) // if user wants to make changes
				{
					l1.moveRight(num);
				}
				
				system("cls");				
			}
			break;
		case 5: //Enter 5 = For moving the left pointer leftwards
			{
				int num;

				cout << "\n\tEnter -999 to return to main menu or " // for returning to main menu
					<<"\n\tEnter the number of nodes you want to move left pointer leftwards: "; // number of nodes to move left pointer left

				cin >> num;

				if(num != -999) // if user wants to make changes
				{
					l1.moveLeft(num);
				}

				system("cls");
			}
			break;
		case 6: //Enter 6 = For displaying list
			{
				int num;

				cout << "\n\tEnter -999 to return to main menu or " // for returning to main menu
					<<"\n\tEnter 1 = For displaying right to left " // prompt to display values on left side of left pointer
					<<"\n\tEnter 2 = For displaying left to right\n\tEnter your choice: "; // prompt to display values on right side of right pointer
				cin >> num;

				system("cls");

				if(num != -999) // if user wants to display
				{
					if(num == 1) // this will print all the values on left side of left pointer
					{
						cout << "\n Right to Left display: ";
						l1.printLeft();
					}
					else // this will print all the values on right side of right pointer
					{
						cout << "\n Left to Right display: ";
						l1.printRight();
					}

					cout << '\n';
				}
			}
			break;
		case 7: //Enter 7 = For removing all of the elements in Linked List
			{
				char choice2;

				cout << "\n\tDo you really want to remove all the elements of Linked List(Y/N): ";
				cin >> choice2;

				if(choice2 == 'y' || choice2 == 'Y') // if user wants to detroy the list
				{
					l1.~LinkedList(); 
				}
				system ("cls");
			}
			break;
		}

	}
}

void main()
{	
	system("color F0"); // this statement changes background color of console from black to white
						// and font color from white to black
	driverLinkedList(); // the menu driven program
}