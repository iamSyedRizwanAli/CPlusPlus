#include <iostream>
#include"StrTok.h"
using namespace std;

int main ()
{
  char str[] ="- This, a `sample string.";
  char * pch;
  pch = strtoK (str," ,.-");
  cout << pch << endl;
  while (pch != NULL)
  {
	  pch = strtoK(NULL, " ,.-");
	if(pch != NULL)
		cout << pch << endl;
  }
  return 0;
}