#ifndef STRTOK_H
#define STRTOK_H
class StrTok
{
	char * vMemory;
	char * token;
	
	StrTok(const StrTok &);
	char * ifStrNull(const char * delim);
	char * ifTokenSizeZero(int vMemorySize);
	char * ifTokenSizeNotZero(int tokenSize, int vMemorySize);
	char * ifStrNotNull(char * str, const char * delim);
	char * ifTokenSizeZeroForStrNotNull(char * str);
	char * ifTokenSizeNotZeroForStrNotNull(int tokenLength, char * str);
	int countTheCharB4anyDelim(const char * c, const char * const delim);
	int getSize(const char * c);
public:
	StrTok();
	char * operator()(char * str, const char * delim);
};
static StrTok strtoK;
#endif