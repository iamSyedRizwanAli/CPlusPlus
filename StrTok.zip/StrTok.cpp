#include"StrTok.h"

#define NULL 0

StrTok :: StrTok()
{
	token = 0;
	vMemory = 0;
}

char * StrTok :: operator()(char * str, const char * delim)
{
	if(str == NULL)
	{
		return ifStrNull(delim);
	}
	else
	{
		return ifStrNotNull(str, delim);
	}
}


char * StrTok :: ifTokenSizeZeroForStrNotNull(char * str)
{
	token = new char [1];
	token[0] = '\0';
	
	int strLength = getSize(str);
	int vMemorySize = strLength;

	vMemory = new char[vMemorySize + 1];
	int j = 0;
	int i = 1;
	while(i < strLength)
	{
		vMemory[j] = str[i++];
		j++;
	}
	vMemory[j] = '\0';
		
	str = token;
		
	return token;
}

char *StrTok :: ifTokenSizeNotZeroForStrNotNull(int tokenLength, char * str)
{
	token = new char [tokenLength + 1];

	int i = 0;

	while(i < tokenLength)
	{
		token[i] = str[i++];
	}
	token[i] = '\0';

	int strLength = getSize(str);
	int vMemorySize = strLength - tokenLength;

	vMemory = new char[vMemorySize + 1];

	int j = 0;

	while(i < strLength)
	{
		vMemory[j] = str[i++];
		j++;
	}
	vMemory[j] = '\0';

	str = token;
	return token;
}

char * StrTok :: ifStrNotNull(char * str, const char * delim)
{
	int tokenLength = countTheCharB4anyDelim(str, delim);

	if(tokenLength == 0)
	{
		return ifTokenSizeZeroForStrNotNull(str);
	}
	return ifTokenSizeNotZeroForStrNotNull(tokenLength, str);
}

char * StrTok :: ifTokenSizeZero(int vMemorySize)
{
	if(token)
			delete [] token;

		if(vMemory[0] == '\0')
		{
			token = NULL;
			vMemory = NULL;
			return NULL;
		}

		token = new char [1];
		token[0] = '\0';

		char * temp = new char[vMemorySize + 1];

		int j = 0;
		int i = 1;
		while(i < vMemorySize)
		{
			temp[j] = vMemory[i++];
			j++;
		}
		temp[j] = '\0';
		
		delete [] vMemory;

		vMemory = temp;

		temp = 0;

		return token;
}

char * StrTok :: ifTokenSizeNotZero(int tokenSize, int vMemorySize)
{
	if(token)
	{
		delete [] token;
		token = 0;
	}

	token = new char [tokenSize + 1];

	int i = 0;
	while( i < tokenSize)
	{
		token[i] = vMemory[i++];
	}
	token[i] = '\0';

	int newVMemorySize = vMemorySize - tokenSize;
	int j = 0;

	char * temp = new char [newVMemorySize + 1];

	while(i < vMemorySize)
	{
		temp[j] = vMemory[i];
		j++;
		i++;
	}
	temp[j] = '\0';

	delete [] vMemory;

	vMemory = temp;
	temp = 0;
	
	return token;
}

char * StrTok :: ifStrNull(const char * delim)
{
	int tokenSize = countTheCharB4anyDelim(vMemory, delim);
	int vMemorySize = getSize(vMemory);

	if(tokenSize == 0)
	{
		return ifTokenSizeZero(vMemorySize);
	}
	return ifTokenSizeNotZero(tokenSize, vMemorySize);

}

int StrTok :: getSize(const char * c)
{
	int i = 0;
	while(c[i++] != '\0');
	return i;
}

int StrTok :: countTheCharB4anyDelim(const char * c, const char * const delim)
{
	int strLength = getSize(c);
	int delimLength = getSize(delim);

	int i = 0, j = 0;
	bool flag = true;
	while(i < strLength && flag == true)
	{
		while(j < delimLength && flag == true)
		{
			if(c[i] != delim[j])
			{
				j++;
			}
			else
				flag = false;
		}
		if(flag == true)
			i++;
		j = 0;
	}

	return i;
}