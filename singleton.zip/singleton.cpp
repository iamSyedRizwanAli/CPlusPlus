#include<iostream>
class Singleton
{
private:
	Singleton()
	{}
	~Singleton()
	{}
	static Singleton * ptr;
public:
	static Singleton * CreateObject()
	{
		if (!ptr)
		{
			ptr = new Singleton;
			return ptr;
		}
		else
			return ptr;
	}

	static void freeObject()
	{
		if (ptr)
		{
			delete ptr;
			ptr=0;
		}
	}
};
Singleton * Singleton::ptr=0;

int main()
{
	Singleton * p = Singleton :: CreateObject();
	std :: cout << (long int)p << std :: endl;
	p->freeObject();
	std :: cout << (long int)p << std :: endl;
	Singleton * q = Singleton :: CreateObject();
	std :: cout << (long int)q << std :: endl;

	return 0;
}