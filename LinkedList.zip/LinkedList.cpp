#include "LinkedList.h"
#include <iostream>

LinkedList :: LinkedList()
{
	head = 0;
}

LinkedList :: LinkedList(const LinkedList & orig)
{
	if(orig.head == NULL)
	{
		head = 0;
	}	
	else
	{
		head = new Node;

		head -> data = orig.head ->data;
		Node * O = orig.head -> next;
		Node * temp = head;

		while(O != NULL)
		{
			temp -> next = new Node;
			temp = temp -> next;
			temp ->data = O -> data;
			O = O -> next;
		}
		temp -> next = 0;
	}
}

bool LinkedList :: search(int val)
{
	if(head != 0)
	{
		Node * temp = head;
		while(temp != 0)
		{
			if(temp -> data == val)
				return true;
			else
				temp = temp -> next;
		}
		return false;
	}
	else
		return false;
}

void LinkedList :: insertAtEnd(int val)
{
	Node * temp = new Node, *tempB;

	temp -> data = val;
	temp -> next = 0;

	tempB = head;

	if(tempB != 0)
	{
		while(tempB -> next != 0)
		{
			tempB = tempB -> next;	
		}
		tempB -> next = temp;

		temp = 0;
	}
	else
	{
		head = temp;
		temp = 0;
	}
}

void LinkedList :: insertAtStart(int val)
{
	Node * temp = new Node;
	temp -> data = val;
	temp -> next = head;
	head = temp;
}

void LinkedList :: insertSorted(int val)
{
	Node * temp = new Node;
	temp -> data = val;

	Node * curr = head, *prev = 0;

	while(curr != 0 && curr -> data < val)
	{
		prev = curr;
		curr = curr -> next;
	}
	if(curr == head)
	{
		temp -> next = head;
		head = temp;
	}
	else
	{
		prev-> next = temp;
		temp ->next = curr;
	}
}

void LinkedList :: display()
{
	if(head)
	{
		Node * temp= head;

		while(temp != 0)
		{
			std :: cout << temp -> data << " ";
			temp = temp->next;
		}
	}
}

LinkedList :: ~LinkedList()
{
	if(head)
	{
		Node * tempA;

		while(head != 0)
		{
			tempA = head->next;
			delete head;
			head = tempA;
		}
	}
}