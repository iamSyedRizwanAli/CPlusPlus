#include"LinkedList.h"
#include<iostream>
using namespace std;

void main()
{
	LinkedList l1;
	l1.insertAtEnd(4);
	l1.insertAtEnd(5);
	l1.insertAtEnd(8);
	
	l1.insertSorted(7);
	l1.insertSorted(6);

	l1.display();
}