#ifndef LINKEDLIST_H
#define LINKEDLIST_H

class LinkedList;

class Node
{
	friend class LinkedList;
	int data;
	Node * next;
};

class LinkedList
{
	Node * head;
public:
	LinkedList();
	LinkedList(const LinkedList & orig);
	bool search(int val);
	void insertAtEnd(int val);
	void insertAtStart(int val);
	void insertSorted(int val);
	/*bool remove(int val);
	bool removeSorted(int val);
	bool removeAll(int val);
	bool removeAllSorted(int val);*/
	void display();
	~LinkedList();
};

#endif