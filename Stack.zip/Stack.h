#ifndef STACK_H
#define STACK_H

class Stack
{
	int * arr;
	int top;
	int maxSize;

	bool isEmpty();
	bool isFull();

public:

	Stack(int size);
	Stack(const Stack & st);
	bool push(int val);
	bool pop(int & val);
	bool getTop(int & val);
	Stack & operator = (const Stack & s);
	~Stack();
	
	int getSize();

	void displayStack();

};

#endif