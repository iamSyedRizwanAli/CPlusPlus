#ifndef GENERALINFIXTOPOSTFIX_H
#define GENERALINFIXTOPOSTFIX_H

class GeneralInfixToPostfix
{
	static int precedence(char c);
	static bool checkIfNegation(char oper, char * string ,int index);
public:
	static char * infixToPostfix(char * c);
	
	static int sizeOfString(char * c);
	static bool isOperator(char c);
};

#endif