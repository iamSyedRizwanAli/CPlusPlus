#include"EvaluatePostfix.h"
#include<iostream>
#include<iomanip>
#include"StackD.h"
#include"LogBase2.h"

using namespace std;

bool isUniryOperator(char c)
{
	if(c == '!' || c == '~')
		return 1;
	return 0;
}

double performOperation(double value1, double value2, char c)
{
	if(c == '/')
	{
		return value2/value1;
	}
	else if(c == '*')
	{
		return value1 * value2;
	}
	else if(c == '+')
	{
		return value1 + value2;
	}
	else if(c == '-')
	{
		return value2 - value1;
	}
	else
		return 0;
}

bool EvaluatePostFix :: isValidEquation(char * expression)
{
	bool valid = 0;

	char c;
	int i = 0, operatorCount = 0, operandCount = 0;


	while(expression[i] != '\0')
	{
		c = expression[i];

		if(c == ' ')
		{
			i++;
		}
		else if(isOperator(c))
		{
			if(c == '~' || c == '|' || c == '&')
				valid = 1;
			operatorCount++;
			i++;
		}
		else
		{
			if((c >= '0' && c <= '9') || c == '.')
			{
				i++;

				c = expression[i];

				while(c != ' ' && c != '\0')
				{
					i++;
					c = expression[i];
				}
				operandCount++;
			}
		}
	}
	
	if(operandCount == operatorCount && valid)
	{
		return true;
	}
	else if(operandCount == (operatorCount + 1) && !valid)
	{
		return true;
	}
	else
		return false;

}

void EvaluatePostFix ::EvaluatePostFixExpression(char * expression)
{
	if(isValidEquation(expression))
	{

		float sizeX = GeneralInfixToPostfix ::sizeOfString(expression);

		float sizeY = sizeX / 2;

		int stackSize = LogBase2 :: ceiling(sizeY);
	
		StackD stack(stackSize);

		int i = 0, tempX;
		double tempY;

		char c;
		bool flag = 0;

		while(expression[i] != 0)
		{
			c = expression[i];

			if(c == ' ')
			{
				i++;
				flag = 1;
			}
			if((c >= '0' && c <= '9') || c =='.')
			{
				if(c == '.')
				{
					stack.pop(tempY);
					i++;
						
					c = expression[i];

					int exp = 1;

					while(c != ' ')
					{
						float tempZ = (c - 48) / (pow(10,exp));
										
						tempY += tempZ;
						i++;
						c = expression[i];
						exp++;
						flag = 1;
					}
	
					cout << "\nToken = " << tempY << "\t\t";
					stack.push(tempY);
					cout << "Push " << tempY << "\t\t";
				}
				else
				{
					tempX = c - 48;
					int tempB;
				
					i++;
						
					c = expression[i];
					flag = 1;
						
					while(c != ' ' && c != '.')
					{
						tempB = c - 48;
						tempX = (tempX * 10) + tempB;
						i++;
						c = expression[i];
					}

					cout << "\nToken = " << tempX << "\t\t";
					stack.push(tempX);
					cout << "Push " << tempX << "\t\t";
				}	
			}
			else if(GeneralInfixToPostfix ::isOperator(c))
			{
				cout << "\nToken = " << c << "\t\t";
					
				if(isUniryOperator(c))
				{
					double tempA;
						
					stack.pop(tempA);

					cout << "Pop " << tempA << "\t\t";

					tempA = -tempA;

					stack.push(tempA);

					cout << "Push " << tempA;
				}
				else
				{
					double value1, value2;
						
					stack.pop(value1);

					cout << "Pop " << value1 << "\t\t";

					stack.pop(value2);

					cout << "Pop " << value2 << "\t\t";

					value1 = performOperation(value1, value2, c);

					stack.push(value1);

					cout << "Push " << value1 ;
				}
			}

			if(!flag)
			{
				i++;
			}
			else
			{
				flag = 0;
			}
		}


			cout << "\nEnd of Input\n";
			
			double result;

		stack.pop(result);
		
		cout << "\nAnswer = " << result << '\n';
	}
	else
	{
		cout << "Invalid equation";
	}
}