#include<iostream>
#include"Stack.h"
#include "addingLargeNumbers.h"
using namespace std;

int AddingLargeNumbers :: sizeOfString(const char * c)
{
	int i = 0;

	while(c[i++] != 0);

	return i - 1;
}

Stack AddingLargeNumbers :: getStackFromChar(char * c)
{
	int size = sizeOfString(c);

	Stack st(size);

	int val = 0;

	for(int i = 0 ; i < size; i++)
	{
		val = c[i] - 48;
		st.push(val);
	}

	return st;
}

char * AddingLargeNumbers :: getStringFromStack(Stack st1)
{
	int i = 0;

	int size = st1.getSize() + 1;

	char * c = new char [size];
	int temp;


	for(i ; i < size - 1 ; i++)
	{
		st1.pop(temp);
		c[i] = temp + 48;
	}

	c[i] = '\0';

	return c;
}

Stack AddingLargeNumbers :: addStacks(Stack temp1, Stack temp2)
{

	int size1 = temp1.getSize();
	int size2 = temp2.getSize();
	int size3;

	if(size1 >= size2)
		size3= size1;
	else
		size3 = size2;

	Stack resultStack(size3);

	int value1, value2, carry = 0, sum = 0;

	while(temp1.getTop(value1) && temp2.getTop(value2))
	{
		sum = value1 + value2 + carry;
		carry = sum / 10;
		sum %= 10;
		
		resultStack.push(sum);

		temp1.pop(value1);
		temp2.pop(value2);
	}
	while(temp1.getTop(value1))
	{
		sum = value1 + carry;
		carry = sum / 10;
		sum %= 10;
		
		resultStack.push(sum);

		temp1.pop(value1);
	}
	while(temp2.getTop(value2))
	{
		sum = value2 + carry;
		carry = sum / 10;
		sum %= 10;
		
		resultStack.push(sum);

		temp2.pop(value2);
	}

	return resultStack;
}

char * AddingLargeNumbers :: addLargeNumbers(char * num1, char * num2)
{
	Stack st1 = getStackFromChar(num1);
	Stack st2 = getStackFromChar(num2);

	Stack resultStack = addStacks(st1,st2);

	char * rStack = getStringFromStack(resultStack);

	return rStack;
}