#ifndef EVALUATEPOSTFIX_H
#define EVALUATEPOSTFIX_H

#include"generalInfoxToPostfix.h"

class EvaluatePostFix : public GeneralInfixToPostfix
{
	static bool isValidEquation(char * expression);
public:
	static void EvaluatePostFixExpression(char * expression);
};

#endif