#include<iostream>
#include"Stack.h"
#include"addingLargeNumbers.h"
#include"LogBase2.h"
#include"FullyParanthasizedInfix.h"
#include"generalInfoxToPostfix.h"
#include"EvaluatePostfix.h"
using namespace std;

//void main()
//{
//	Stack s1(5);
//
//	for(int i = 0 ; i < 5 ; i++)
//		s1.push(i);
//
//	int val;
//
//	for(int i = 0 ; i < 5 ; i++)
//	{
//		s1.pop(val);
//		cout << val << endl;
//	}
//}

void main()
{
	char num1[200];
	/*char num2[30];

	cout << "number 1 : ";
	cin.getline(num1,30);
	cout << "number 2 : ";
	cin.getline(num2,30);

	char * result = AddingLargeNumbers :: addLargeNumbers(num1,num2);

	cout << '\n' << result;

	delete [] result;
	result = 0;*/

	cout << "Enter Infix : ";
	cin.getline(num1,200);

//	char * temp;

//	temp = GeneralInfixToPostfix :: infixToPostfix(num1);

//	cout << "Postfix notation: " << temp << '\n';

	EvaluatePostFix :: EvaluatePostFixExpression(num1);

//	delete [] temp; 
//	temp = 0;

}