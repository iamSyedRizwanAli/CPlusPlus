#include "LogBase2.h"

int LogBase2 :: power(const int base, const int exponent)
{
	int temp = 1;
	int count = 1 ;

	while(count <= exponent)
	{
		temp *= 2;
		count ++;
	}

	return temp;
}

float LogBase2 :: getLog(const int value)
{
	if(value <= 0)
		return -1;
	else if(value == 1)
		return 0;

	int exponentFixed = 0, comparisonValue;

	while(value > power(2, exponentFixed))
	{
		exponentFixed++;
	}

	int temp = power(2, exponentFixed);
	comparisonValue = power(2, exponentFixed - 1);

	if(value == temp)
		return exponentFixed;
	else
	{
		exponentFixed--;

		int count = 0, temp2;
		float exponentFloat, deviation, valueAfterLog, difference;

		valueAfterLog = exponentFixed;

		difference = temp - comparisonValue;

		deviation = 1/difference;

		while(comparisonValue < value)
		{
			comparisonValue++;
			count++;
		}

		exponentFloat = count * deviation;

		valueAfterLog += exponentFloat;

		return valueAfterLog;
	}
}

int LogBase2 :: ceiling(const float value)
{
	int temp = value;

	if(value > temp)
		return temp + 1;
	else
		return temp;
}

int LogBase2 :: floor(const float value)
{
	int temp = value;

	return temp;
}