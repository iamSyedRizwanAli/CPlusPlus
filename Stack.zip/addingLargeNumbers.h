#ifndef ADDINGLARGENUMBERS_H
#define ADDINGLARGENUMBERS_H

#include"Stack.h"

class AddingLargeNumbers
{
	static int sizeOfString(const char * c);
	static Stack addStacks(Stack temp1, Stack temp2);
	static char * getStringFromStack(Stack st1);
	static Stack getStackFromChar(char * c);
public:
	static char * addLargeNumbers(char * num1, char * num2);

};

#endif