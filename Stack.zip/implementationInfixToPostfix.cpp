#include "implementationInfixToPostfix.h"
#include "Stack.h"
#include "LogBase2.h"

int implementInfixToPostifx ::precedence(char c)
{
	if(c == '!')
		return 5;
	if(c == '*' || c == '/' || c == '%')
		return 4;
	if(c == '+' || c == '-')
		return 3;
	if(c == '<' || c == '>')
		return 2;
	if(c == '(')
		return 1;
	return 0;
}

bool implementInfixToPostifx :: isOperator(char c)
{
	if(c == '!' || c == '*' || c == '/' || c == '%' || c == '+' || c == '-')
		return true;
	else
		return false;
}

bool implementInfixToPostifx :: isUniray(char c)
{
	if(c == '!' || c == '~')
		return 1;
	return 0;
}

int implementInfixToPostifx :: sizeOfString(char * c)
{
	int i = 0; 

	while(c[i++] != 0);

	return i ;
}

char * implementInfixToPostifx :: infixToPostfix(char *c)
{
	float sizeA = sizeOfString(c);
	
	float sizeB = sizeA / 2;

	int size = sizeA;

	int stackSize = LogBase2 ::floor (sizeB);

	Stack stack(stackSize);

	char * result = new char [size];
	int i = 0; 
	int j = 0;

	while(c[i] != 0)
	{
		char ch = c[i];

		if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z'))
		{
			result[j] = ch;
			j++;
		}
		else if(ch == '(')
		{
			stack.push(ch);
		}
		else if(isOperator(ch))
		{
			int tempB;

			stack.getTop(tempB);

			if(precedence(ch) > precedence(tempB))
			{
				stack.push(ch);
			}
			else
			{
				while(stack.pop(tempB) && precedence(ch) <= precedence(tempB))
				{
					result[j] = tempB;
					j++;
				}
				stack.push(ch);
			}
		}
		else if( ch == ')')
		{
			int tempE;
			stack.getTop(tempE);

			while(tempE != '(')
			{
				stack.pop(tempE);
				result[j] = tempE;
				j++;
				stack.getTop(tempE);
			}
			stack.pop(tempE);
		}

		i++;
	}

	int tempD;

	while(stack.pop(tempD))
	{
		result[j] = tempD;
		j++;
	}
	result[j] = '\0';

	return result;
}