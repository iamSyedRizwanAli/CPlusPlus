#include<iostream>
#include"Stack.h"
using namespace std;

Stack :: Stack(int size)
{
	maxSize = size;
	top = -1;
	arr = new int [maxSize];
}

Stack :: Stack(const Stack & st)
{
	maxSize = st.maxSize;
	arr = new int [maxSize];
	top = st.top;

	for(int i = 0 ; i <= top ; i++)
		arr[i] = st.arr[i];

}

bool Stack :: isFull()
{
	if(top == maxSize - 1)
		return true;
	else
		return false;
}

bool Stack :: isEmpty()
{
	if(top < 0)
		return true;
	else
		return false;
}

bool Stack :: push(int val)
{
	if(!isFull())
	{
		top++;
		arr[top] = val;
		return true;
	}
	else
		return false;
}

bool Stack :: pop(int & val)
{
	if(!isEmpty())
	{
		val = arr[top];
		top --;
		return true;
	}
	else
		return false;
}

bool Stack :: getTop(int & val)
{
	if(!isEmpty())
	{
		val = arr[top];
		return true;
	}
	else
		return false;
}

Stack :: ~Stack()
{
	if(arr)
	{
		delete [] arr;
		arr = 0;
	}
}

Stack & Stack :: operator=(const Stack & st)
{
	if(&st == this)
	{
		return *this;
	}
	else
	{
		if(arr)
			this -> ~Stack();

		maxSize = st.maxSize;
		top = st.top;
		arr = new int [st.maxSize];

		for(int i = 0 ; i <= top ; i++)
			arr[i] = st.arr[i];

		return *this;
	}
}

int Stack :: getSize()
{
	return maxSize;
}

void Stack :: displayStack()
{
	for(int i = 0 ; i <= top ; i++)
		cout << arr[i] << endl;
}