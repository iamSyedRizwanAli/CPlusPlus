#include"generalInfoxToPostfix.h"
#include"Stack.h"
#include"LogBase2.h"

int GeneralInfixToPostfix ::precedence(char c)
{
	if(c == '!' || c == '~')
		return 5;
	if(c == '*' || c == '/' || c == '%')
		return 4;
	if(c == '+' || c == '-')
		return 3;
	if(c == '<' || c == '>')
		return 2;
	if(c == '(')
		return 1;
	return 0;
}

bool GeneralInfixToPostfix :: isOperator(char c)
{
	if(c == '!' || c == '~' || c == '*' || c == '/' || c == '%' || c == '+' || c == '-' || c == '&' || c == '|')
		return true;
	else
		return false;
}

bool GeneralInfixToPostfix :: checkIfNegation(char oper, char * string ,int index)
{
	if(oper == '-')
	{
		if(isOperator(string[index - 1]) || isOperator(string[index - 2]))
		{
			return true;
		}
		else if(string[index - 1] == '(' || string[index - 2] == '(')
		{
			return true;
		}
		else
			return false;
	}
	else
		return false;
}

int GeneralInfixToPostfix :: sizeOfString(char * c)
{
	int i = 0; 

	while(c[i++] != 0);

	return i ;
}

char * GeneralInfixToPostfix :: infixToPostfix(char *c)
{
	float sizeA = sizeOfString(c);
	
	float sizeB = sizeA / 2;

	int size = (2 * sizeA);

	int stackSize = LogBase2 ::floor (sizeB);

	Stack stack(stackSize);

	char * result = new char [size];
	int i = 0; 
	int j = 0;

	while(c[i] != 0)
	{
		char ch = c[i];

		if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9') || ch == '.')
		{
			result[j] = ch;
			j++;
		}
		else if(ch == '(')
		{
			stack.push(ch);
		}
		else if(isOperator(ch))
		{

			int tempB;

			if(checkIfNegation(ch, c, i))
			{
				ch = '~';
			}
			else
			{
				result[j] = ' ';
				j++;
			}

			stack.getTop(tempB);

			if(precedence(ch) > precedence(tempB))
			{
				stack.push(ch);
			}
			else
			{
				while(stack.pop(tempB) && precedence(ch) <= precedence(tempB))
				{
					result[j] = tempB;
					j++;
				}
				stack.push(ch);
				result[j] = ' ';
				j++;
			}
		}
		else if( ch == ')')
		{
			int tempE;
//			stack.getTop(tempE);

			while(stack.getTop(tempE) && tempE != '(')
			{
				result[j] = ' ';
				j++;
				stack.pop(tempE);
				result[j] = tempE;
				j++;
				stack.getTop(tempE);
			}
			stack.pop(tempE);
		}

		i++;
	}

	int tempD;

	result[j] = ' ';
	j++;

	while(stack.pop(tempD))
	{
		result[j] = tempD;
		j++;
		result[j] = ' ';
		j++;
	}
	result[j] = '\0';

	return result;
}