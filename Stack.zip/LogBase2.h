#ifndef LOGBASETWO_H
#define LOGBASETWO_H

class LogBase2
{
	static int power(const int base, const int exponent);
public:
	static float getLog(const int value);
	static int ceiling(const float value);
	static int floor(const float value);
};

#endif