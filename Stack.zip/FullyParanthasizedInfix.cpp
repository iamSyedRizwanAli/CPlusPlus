#include"FullyParanthasizedInfix.h"
#include"LogBase2.h"
#include"Stack.h"

int FullyParanthasizedInfixToPostfix :: sizeOfString(const char * c)
{
	int i = 0;

	while(c[i++] != 0);

	return i - 1;
}

int FullyParanthasizedInfixToPostfix :: precedence(char c, bool position)
{
	if(c == '!')
		return 1;
	if(c == '*' || c == '/' || c == '%')
		return 2;
	if(c == '+' || c == '-')
		return 3;
	if(c == '<' || c == '>')
		return 4;
	if(c == '(')
	{
		if(position == 0)
			return 4;
		else
			return 0;
	}
}

char * FullyParanthasizedInfixToPostfix :: infixToPostfix(char * c)
{
	int tempX = sizeOfString(c);

	char * postFix = new char [tempX];

	Stack stack(tempX - 1);


	int i = 0, j = 0;

	while(c[i] != 0)
	{
		int temp  = c[i];
		
		if(c[i] != ')')
			stack.push(temp);
		else
		{
			char c2 = temp;

			while( c2 != '(')
			{
				stack.pop(temp);
				c2 = temp;
				postFix[j] = c2;
				j++;
				stack.getTop(temp);
				c2 = temp;
			}
			stack.pop(temp);
		}

		i++;
	}
	postFix[j] = '\0';

	return postFix;
}