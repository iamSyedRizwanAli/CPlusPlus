#ifndef FULLYPARANTHASIZEDINFIX_H
#define FULLYPARANTHASIZEDINFIX_H

class FullyParanthasizedInfixToPostfix
{
	static int sizeOfString(const char * c);
	static int precedence(char ch, bool position);
public:
	static char * infixToPostfix(char * c);
};

#endif