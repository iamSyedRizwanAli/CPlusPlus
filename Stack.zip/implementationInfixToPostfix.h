#ifndef IMPLEMENTATIONINFIXTOPOSTFIIX_H
#define IMPLEMENTATIONINFIXTOPOSTFIIX_H

class implementInfixToPostifx
{
	static int precedence(char c);
	static int sizeOfString(char * c);
	static bool isOperator(char c);
	bool isUniray(char c);
public:
	static char * infixToPostfix(char * c);
};

#endif