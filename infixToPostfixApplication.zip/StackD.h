#ifndef STACKD_H
#define STACKD_H

class StackD
{
	double * arr;
	int top;
	int maxSize;

	bool isEmpty();
	bool isFull();

public:

	StackD(int size);
	StackD(const StackD & st);
	bool push(double val);
	bool pop(double & val);
	bool getTop(double & val);
	StackD & operator = (const StackD & s);
	~StackD();
	
	int getSize();
};

#endif