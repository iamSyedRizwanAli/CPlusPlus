#include<iostream>
#include"itp.h"
#include<cmath>
#include<cctype>
#include<cstdlib>
#include<cstring>
#include"Stack.h"
#include"StackD.h"
using namespace std;

int ITP ::sizeOfExpression(char * expression)
{
	int i = 0;

	while(expression[i] != 0)
	{
		i++;
	}
	return i;
}

bool ITP :: isOperator(char c)
{
	if(c == '+' || c == '-' || c == '!' || c == '~' || c == '*' || c == '/' || c == '%' || c == '|' || c == '&')
		return true;
	else
		return false;
}

bool ITP :: isUnaryOperator(char ch)
{
	if(ch == '!' || ch == '~')
		return true;
	else
		return false;
}

bool ITP :: isInfixOrPostfix(char * expression)
{
	int size = sizeOfExpression(expression);

	if(isOperator(expression[size - 1]))
		return 1;
	else
		return 0;
}

bool ITP :: isInfixAlright(char * expression)
{
	int operatorCount = 0, operandCount = 0 ;
	int i = 0;
	bool unaryFlag = 0;

	while(expression[i] != 0)
	{
		if(isOperator(expression[i]))
		{		
			if(isUnaryOperator(expression[i]))
				unaryFlag = 1;

			operatorCount++;
		}
		else if(isdigit(expression[i]))
		{
			while(expression[i] != ' ')
				i++;
			operandCount++;
		}
		i++;
	}

	if(operandCount <= operatorCount && unaryFlag)
		return true;
	else if(operandCount == operandCount -1)
		return true;
	else
		return false;
}

int ITP :: precedence(char ch)
{
	if(ch == '!' || ch == '~')
		return 6;
	else if (ch == '/' || ch == '*' || ch == '%')
		return 5;
	else if(ch == '+' || ch == '-')
		return 4;
	else if(ch == '<' || ch == '>')
		return 3;
	else if(ch == '&'|| ch == '|')
		return 1;
	else if(ch == '(')
		return 0;
	else
		return -1;
}

double ITP :: operation(char c, double value1, double value2)
{
	if(c == '+')
	{
		return value1 + value2;
	}
	else if(c == '*')
	{
		return value1 * value2;
	}
	else if(c == '-')
	{
		return value2 - value1;
	}
	else if(c == '/')
	{
		return value2/value1;
	}
	else
		return 0;
}

char * ITP :: infixToPostfix(char * expression)
{
	float size = sizeOfExpression(expression);

	int size1 = size;

	char * temp = new char [size1];

	int stackSize = floor(size / 2);

	Stack stack(stackSize);

	int i = 0 , j = 0 ; 
	bool flag = 0;

	while(expression[i] != 0)
	{
		if(expression[i] == '(')
			stack.push('(');
		else if(isdigit(expression[i]))
		{
			temp[j] = expression[i];
			j++;
			i++;
			flag = 1;

			while(expression[i] != ' ')
			{
				temp[j] = expression[i];
				j++;
				i++;
			}
			temp [j] = ' ';
			j++;
		}
		else if(isOperator(expression[i]))
		{
			int tempA;
			char ch = expression[i];

			if(stack.getTop(tempA))
			{
				if(expression[i - 1] == '(' || expression[i - 2] == '(')
				{
					ch = '~';
				}
				if(precedence(tempA) < precedence(ch))
				{
					stack.push(ch);
				}
				else
				{
					while(precedence(tempA) > precedence(ch))
					{
						stack.pop(tempA);
						temp[j] = tempA;
						j++;
						temp[j] = ' ';
						j++;
						stack.getTop(tempA);
					}
				}
			}
			else
			{
				stack.push(expression[i]);
			}
		}
		else if(expression[i] == ')')
		{
			int tempB;
			while(stack.pop(tempB))
			{
				temp[j] = tempB;
				j++;
				temp[j] = ' ';
				j++;
			}
		}

		if(!flag)
			i++;
	}
	temp[i] = 0;

	return temp;
}

double ITP :: evaluatePostfix(char * expression)
{
	bool check1 = 0;
	
	char * temp;

	if(isInfixOrPostfix(expression))
	{
		if(!isInfixAlright(expression))
		{
			cout << "Wrong input";
			return -11111;
		}
		else
			temp = expression;
	}
	else
	{
		temp = infixToPostfix(expression);
		check1 = 1;
	}

	float size = sizeOfExpression(expression);

	int stackSize = floor(size / 2);

	StackD stack(stackSize);

	int i = 0;

	while(temp [i] != 0)
	{
		if(isOperator(temp[i]))
		{
			double tempA;
			if(isUnaryOperator(temp[i]))
			{
				stack.pop(tempA);
				stack.push(-tempA);
			}
			else
			{
				double value1, value2;

				stack.pop(value2);
				stack.pop(value1);
				double result = operation(temp[i], value1, value2);
				stack.push(result);
			}
		}
		if(isdigit(temp[i]))
		{
			char delim[2] = {32, 0};
			char * token = strtok(expression, " ,");
			double tempB = atof(token);
			stack.push(tempB);
			delete [] token;
			token = 0;
		}
		i++;
	}

	double finalResult;

	stack.pop(finalResult);

	if(check1)
	{
		delete [] temp;
	}
	temp = 0;

	return finalResult;
}