#ifndef ITP_H
#define ITP_H

class ITP
{

	static int sizeOfExpression(char * expression);
	static bool isOperator(char c);
	static bool isUnaryOperator(char c);
	static int precedence(char c);
	static bool isInfixOrPostfix(char * expression);
	static bool isInfixAlright(char * expression);
	static char * infixToPostfix(char * expression);

	static double operation(char c, double value1, double value2);
public:
	static double evaluatePostfix(char * expression);
};

#endif