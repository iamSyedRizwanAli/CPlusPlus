#include<iostream>
#include"StackD.h"
using namespace std;

StackD :: StackD(int size)
{
	maxSize = size;
	top = -1;
	arr = new double [maxSize];
}

StackD :: StackD(const StackD & st)
{
	maxSize = st.maxSize;
	arr = new double [maxSize];
	top = st.top;

	for(int i = 0 ; i <= top ; i++)
		arr[i] = st.arr[i];

}

bool StackD :: isFull()
{
	if(top == maxSize - 1)
		return true;
	else
		return false;
}

bool StackD :: isEmpty()
{
	if(top < 0)
		return true;
	else
		return false;
}

bool StackD :: push(double val)
{
	if(!isFull())
	{
		top++;
		arr[top] = val;
		return true;
	}
	else
		return false;
}

bool StackD :: pop(double & val)
{
	if(!isEmpty())
	{
		val = arr[top];
		top --;
		return true;
	}
	else
		return false;
}

bool StackD :: getTop(double & val)
{
	if(!isEmpty())
	{
		val = arr[top];
		return true;
	}
	else
		return false;
}

StackD :: ~StackD()
{
	if(arr)
	{
		delete [] arr;
		arr = 0;
	}
}

StackD & StackD :: operator=(const StackD & st)
{
	if(&st == this)
	{
		return *this;
	}
	else
	{
		if(arr)
			this -> ~StackD();

		maxSize = st.maxSize;
		top = st.top;
		arr = new double [st.maxSize];

		for(int i = 0 ; i <= top ; i++)
			arr[i] = st.arr[i];

		return *this;
	}
}

int StackD :: getSize()
{
	return maxSize;
}