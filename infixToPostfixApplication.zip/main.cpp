﻿#include"itp.h"
#include<iostream>

using namespace std;

void main()
{
	cout << ITP :: evaluatePostfix("12 3 ~ 1 - / 4.6 ~ *");
}