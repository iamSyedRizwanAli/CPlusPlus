#ifndef IEEE754_H
#define IEEE754_H
#include"CString.h"
class IEEE754
{
	static int getExponent(const CString & cs);
	static float getFloatingNumber4positiveExpo(CString & cs, int exponenet);
	static float getFloatingNumber4negativeExpo(CString & cs, int exponenet);
	static void getBinaryMantissa(float number, char* mantissa, int count1);
	static void getBinaryExponent(char* exponent, int expo);

	static int getBinaryLengthOfNumberB4Point(int beforePoint, char * mantissa);
public:
	static CString getTheCode4float(float number);
	static float getTheFloatingNumber(CString code);
};
#endif