#include<iostream>
#include"CString.h"
#include"IEEE754.h"
using namespace std;

void main()
{
	IEEE754 :: getTheCode4float(3.1).display();
	cout << IEEE754 ::getTheFloatingNumber(IEEE754 :: getTheCode4float(3.1)) << endl;
}