#ifndef IEEE754DP_H
#define IEEE754DP_H
#include"CString.h"
class IEEE754DP
{
	static int getBinaryLengthOfNumberB4Point(int beforePoint, char * mantissa);

	static int getExponent4double(const CString & cs);
	static double getDoubleNumber4positiveExpo(CString & cs, int exponenet);
	static double getDoubleNumber4negativeExpo(CString & cs, int exponenet);
	static void getBinaryMantissa4Double(float number, char* mantissa, int count1);
	static void getBinaryExponent4Double(char* exponent, int expo);
	
public:
	static CString getTheCode4Double(double number);
	static double getTheDoubleNumber(CString code);
};
#endif