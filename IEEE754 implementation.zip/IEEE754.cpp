#include"IEEE754.h"
#include"CString.h"
#include<cmath>
#include<iostream>

void IEEE754 :: getBinaryExponent(char* exponent, int exp)
{
	int temp, binary1 = 1;
	 while(exp != 0)
	 {
		 temp = exp % 2;
		 binary1 = (binary1 * 10) + temp;
		 exp /= 2;
	 }
	 exp = 0;
	 while(binary1 > 9)
	 {
		 temp = binary1 % 10;
		 exp = (exp * 10) + temp;
		 binary1 /= 10;
	 }
	 for(int i = 7 ; i >= 0 ; i--)
	 {
		temp = exp % 10;
		temp += 48;
		exponent[i] = temp;
		exp /= 10;
	}
}

int IEEE754 ::getExponent(const CString & code)
{
	int expo = 0 , temp , powe, runer = 7;
	for(int i = 1 ; i < 9 ; i++)
	{
		temp = code.at(i) - 48;
		powe = pow(2,runer);
		temp *= powe;
		expo += temp;
		runer--;
	}
	return expo;
}

float IEEE754 :: getFloatingNumber4positiveExpo(CString & code, int expo)
{
	float tempo, power, number = 1;
	int runer = 1, k = 0;

	for(int i = 9 ; i < 32 ; i++)
	{
		tempo = code.at(i) - 48;
		power = pow(2,-runer);
		runer++;
		tempo *= power;
		number += tempo;
	}
	while(k < expo)
	{
		number *= 2;
		k++;
	}
	return number;
}

float IEEE754:: getFloatingNumber4negativeExpo(CString & code, int expo)
{
	float number = 1.00, tempo, power;
	int k = 1 , m = 9;
	while(m < 32)
	{
		tempo = code.at(m) - 48;
		power = pow(2,-k);
		k++;
		tempo *= power;
		m++;
		number += tempo;
	}
	m = 0;
	expo *= -1;
	while(m < expo)
	{
		number /= 2;
		m++;
	}
	return number;
}

void IEEE754 :: getBinaryMantissa(float afterPoint, char* mantissa, int count1)
{
	float divident;
	int runer = count1;
	float temp1;
	for(int i = 1 ; i < 22 && runer < 22 ; i++)
	{
		divident = pow(2,-i);
		temp1 = afterPoint - divident;
		if(temp1 >= 0)
		{
			mantissa[runer++] = '1';
			afterPoint -= divident;
		}
		if(temp1 < 0)
		{
			mantissa[runer++] = '0';
		}
	}
}

int IEEE754 :: getBinaryLengthOfNumberB4Point(int beforePoint, char * mantissa)
{
	int temp, binary1 = 1;
	while(beforePoint != 0)
	{
		temp = beforePoint % 2;
		binary1 = (binary1 * 10) + temp;
		beforePoint /= 2;
	}
	beforePoint = 0;
	int count = 0;
	while(binary1 > 9)
	{
		temp = binary1 % 10;
		beforePoint = (beforePoint * 10) + temp;
		binary1 /= 10;
		if(count > 0)
		{
			mantissa[count-1] = temp + 48;
		}
		count++;
	}
	count--;
	return count;
}

CString IEEE754 :: getTheCode4float(float num)
{
	int signBit = 0;
	if(num < 0)
	{
		signBit = 1;
		num *= -1;
	}
	
	char mantissa[23] = {'0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0','0'};
	char exponent[8] = {'0','0','0','0','0','0','0','0'};
	
	int beforePoint =  num;
	float afterPoint = num - beforePoint;

	if(beforePoint == 0)
	{
		int counter = 0;
		while(beforePoint == 0)
		{
			num *= 2;
			counter++;
			beforePoint = num;
		}
		afterPoint = num - beforePoint;
			
		int count = IEEE754 ::getBinaryLengthOfNumberB4Point(beforePoint,mantissa);
		IEEE754 ::getBinaryMantissa(afterPoint,mantissa,count);
		int exp = 127 - counter;
		IEEE754 :: getBinaryExponent(exponent,exp);
	}
	else
	{	
		int count = IEEE754 ::getBinaryLengthOfNumberB4Point(beforePoint,mantissa);
		IEEE754 ::getBinaryMantissa(afterPoint,mantissa,count);
		int exp = 127 + count;
		IEEE754 ::getBinaryExponent(exponent,exp);
	}
	
	char c = signBit + 48;
	 CString code(c);
	 CString expo(exponent);
	 CString mant(mantissa);
	 code.concatEqual(expo);
	 code.concatEqual(mant);
	 return code;
}

float IEEE754 :: getTheFloatingNumber(CString code)
{
	int sign = code.at(0) - 48;

	int expo = 0;

	expo = IEEE754 ::getExponent(code);

	expo -= 127;
	float number;

	if(expo >= 0)
		number = IEEE754 :: getFloatingNumber4positiveExpo(code, expo);
	if(expo < 0)
		number = IEEE754 :: getFloatingNumber4negativeExpo(code,expo);

	if(sign == 1)
		number *= -1;
	return number;
}