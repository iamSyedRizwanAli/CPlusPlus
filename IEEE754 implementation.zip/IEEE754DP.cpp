#include"IEEE754DP.h"
#include<iostream>

void IEEE754DP :: getBinaryExponent4Double(char* exponent, int expo)
{	
	long long int temp, binary1 = 1, exp = expo;
	 while(exp != 0)
	 {
		 temp = exp % 2;
		 binary1 = (binary1 * 10) + temp;
		 exp /= 2;
	 }
	 exp = 0;
	 while(binary1 > 9)
	 {
		 temp = binary1 % 10;
		 exp = (exp * 10) + temp;
		 binary1 /= 10;
	 }
	 for(int i = 10 ; i >= 0 ; i--)
	 {
		temp = exp % 10;
		temp += 48;
		exponent[i] = temp;
		exp /= 10;
	}
}

int IEEE754DP ::getExponent4double(const CString & code)
{
	int expo = 0 , temp , powe, runer = 10;
	for(int i = 1 ; i < 12 ; i++)
	{
		temp = code.at(i) - 48;
		powe = pow(2,runer);
		temp *= powe;
		expo += temp;
		runer--;
	}
	return expo;
}

double IEEE754DP :: getDoubleNumber4positiveExpo(CString & code, int expo)
{
	double tempo, power, number = 1;
	int runer = 1, k = 0;

	for(int i = 12 ; i < 64 ; i++)
	{
		tempo = code.at(i) - 48;
		power = pow(2,-runer);
		runer++;
		tempo *= power;
		number += tempo;
	}
	while(k < expo)
	{
		number *= 2;
		k++;
	}
	return number;
}

double IEEE754DP :: getDoubleNumber4negativeExpo(CString & code, int expo)
{
	double number = 1.00, tempo, power;
	int k = 1 , m = 12;
	while(m < 64)
	{
		tempo = code.at(m) - 48;
		power = pow(2,-k);
		k++;
		tempo *= power;
		m++;
		number += tempo;
	}
	m = 0;
	expo *= -1;
	while(m < expo)
	{
		number /= 2;
		m++;
	}
	return number;
}

CString IEEE754DP :: getTheCode4Double(double num)
{
	int signBit = 0;
	if(num < 0)
	{
		signBit = 1;
		num *= -1;
	}
	
	char mantissa[52] = {"000000000000000000000000000000000000000000000000000"};
	char exponent[11] = {'0','0','0','0','0','0','0','0','0','0','0'};
	
	int beforePoint =  num;
	double afterPoint = num - beforePoint;

	if(beforePoint == 0)
	{
		int counter = 0;
		while(beforePoint == 0)
		{
			num *= 2;
			counter++;
			beforePoint = num;
		}
		afterPoint = num - beforePoint;
			
		int count = IEEE754DP ::getBinaryLengthOfNumberB4Point(beforePoint,mantissa);
		IEEE754DP ::getBinaryMantissa4Double(afterPoint,mantissa,count);
		int exp = 1023 - counter;
		IEEE754DP :: getBinaryExponent4Double(exponent,exp);
	}
	else
	{	
		int count = IEEE754DP ::getBinaryLengthOfNumberB4Point(beforePoint,mantissa);
		IEEE754DP ::getBinaryMantissa4Double(afterPoint,mantissa,count);
		int exp = 1023 + count;
		IEEE754DP ::getBinaryExponent4Double(exponent,exp);
	}
	
	char c = signBit + 48;
	 CString code(c);
	 CString expo(exponent);
	 CString mant(mantissa);
	 code.concatEqual(expo);
	 code.concatEqual(mant);
	 return code;
}

double IEEE754DP :: getTheDoubleNumber(CString code)
{
	int sign = code.at(0) - 48;

	int expo = 0;

	expo = IEEE754DP ::getExponent4double(code);

	expo -= 1023;
	double number;

	if(expo >= 0)
		number = IEEE754DP :: getDoubleNumber4positiveExpo(code, expo);
	if(expo < 0)
		number = IEEE754DP :: getDoubleNumber4negativeExpo(code,expo);

	if(sign == 1)
		number *= -1;
	return number;
}

int IEEE754DP :: getBinaryLengthOfNumberB4Point(int beforePoint, char * mantissa)
{
	int temp, binary1 = 1;
	while(beforePoint != 0)
	{
		temp = beforePoint % 2;
		binary1 = (binary1 * 10) + temp;
		beforePoint /= 2;
	}
	beforePoint = 0;
	int count = 0;
	while(binary1 > 9)
	{
		temp = binary1 % 10;
		beforePoint = (beforePoint * 10) + temp;
		binary1 /= 10;
		if(count > 0)
		{
			mantissa[count-1] = temp + 48;
		}
		count++;
	}
	count--;
	return count;
}

void IEEE754DP :: getBinaryMantissa4Double(float afterPoint, char* mantissa, int count1)
{
	double divident;
	int runer = count1;
	double temp1;
	for(int i = 1 ; i < 52 && runer < 52 ; i++)
	{
		divident = pow(2,-i);
		temp1 = afterPoint - divident;
		if(temp1 >= 0)
		{
			mantissa[runer++] = '1';
			afterPoint -= divident;
		}
		if(temp1 < 0)
		{
			mantissa[runer++] = '0';
		}
	}
}